export const environment = {
  production: true,
  mapbox: {
    accessToken: 'pk.eyJ1IjoicHJlbWlvbjEiLCJhIjoiY2w5cmMzZDVlMDA2ZTN1bXkwMHJ5a2FpcSJ9.TiV1mtzAoK8sWeD6GvFVKw'
  },
  serverUrl: "https://us-central1-premion-audience-engagement.cloudfunctions.net/",
};
