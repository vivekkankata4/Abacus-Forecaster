import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-filter-list',
  templateUrl: './filter-list.component.html',
  styleUrls: ['./filter-list.component.css']
})
export class FilterListComponent implements OnInit {
  
  @Input() agency_name: string;
  @Input() advertiser_name: string;
  @Input() geo_list: string[];
  @Input() segment_names: string[];
  @Input() publisher_names: string[];

  constructor() { 

  }

  ngOnInit(): void {
    //console.log("My Pub list"+this.publisher_names[0]);
  }

}
