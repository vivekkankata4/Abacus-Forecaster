import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-grid-dash',
  templateUrl: './grid-dash.component.html',
  styleUrls: ['./grid-dash.component.css']
})
export class GridDashComponent implements OnInit {
  
  @Input() agency_name: string;
  @Input() advertiser_name: string;
  @Input() geo_list: string[];
  @Input() segment_names: string[];
  @Input() publisher_names: string[];
  @Input() booked_imps: number;
  @Input() forecasted_imps: number;
  @Input() available_imps: number;
  @Input() monthly_imps: number;
  @Input() weekly_imps: number;
  @Input() daily_imps: number;
  @Input() household_nums: number;
  @Input() total_population: number;
  @Input() dma: string;
  @Input() daypart_data:  any[];
  @Input() ott_data:  any[];
  @Input() isZip:  boolean;  
  constructor() { }

  ngOnInit(): void {
    //console.log("My Pub list in grid-dash "+this.daypart_data);
    //console.log("ott data in grid-dash "+this.ott_data);
  }
  
}
