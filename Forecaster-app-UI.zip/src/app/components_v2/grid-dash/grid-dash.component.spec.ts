import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GridDashComponent } from './grid-dash.component';

describe('GridDashComponent', () => {
  let component: GridDashComponent;
  let fixture: ComponentFixture<GridDashComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GridDashComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GridDashComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
