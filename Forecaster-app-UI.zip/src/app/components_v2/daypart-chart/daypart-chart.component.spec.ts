import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DaypartChartComponent } from './daypart-chart.component';

describe('DaypartChartComponent', () => {
  let component: DaypartChartComponent;
  let fixture: ComponentFixture<DaypartChartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DaypartChartComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DaypartChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
