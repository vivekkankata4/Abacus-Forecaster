import { Component, OnInit, Input } from '@angular/core';
import { NgxChartsModule, Color, ScaleType } from '@swimlane/ngx-charts';

@Component({
  selector: 'app-daypart-chart',
  templateUrl: './daypart-chart.component.html',
  styleUrls: ['./daypart-chart.component.css']
})
export class DaypartChartComponent implements OnInit {

  @Input() daypart_data: any[];
  single: any[];
  multi: any[];

  // options
  showXAxis = true;
  showYAxis = true;
  showLegend = false;
  showXAxisLabel = true;
  xAxisLabel = 'Daypart';
  showYAxisLabel = true;
  yAxisLabel = 'Impressions';
  gradient = true;
  barPadding = 50;

  colorScheme: Color = {
    name: 'Customer Usage',
    selectable: true,
    group: ScaleType.Ordinal,
    domain: ['#5CC2F2']
  };

  constructor() {

    // [
    //   {
    //     name: "Mid-2AM",
    //     value: 6
    //   },
    //   {
    //     name: "2AM-6AM",
    //     value: 14
    //   },
    //   {
    //     name: "6AM-9AM",
    //     value: 14
    //   },
    //   {
    //     name: "9AM-4PM",
    //     value: 32
    //   },
    //   {
    //     name: "4PM-7PM",
    //     value: 9
    //   },
    //   {
    //     name: "7PM-Mid",
    //     value: 22
    //   }
    // ]
  }

  ngOnInit(): void {
    console.log("My Daypart data in dayPart " + this.daypart_data);
    if (this.daypart_data && this.daypart_data.length > 0) {
      this.single = this.daypart_data;
      Object.assign(this.single);
      this.calculatePerentages();
    }
  }

  ngOnChanges(): void {
    console.log("My Daypart data in ngOnChanges " + this.daypart_data);
    if (this.daypart_data && this.daypart_data.length > 0) {
      this.single = this.daypart_data;
      Object.assign(this.single);
      this.calculatePerentages();
    }
  }

  calculatePerentages() {
    let total = 0;
    this.single.forEach(element => {
      total = total + element.value;
    });

    this.single.forEach(element => {
      //console.log(element.value, total);
      element.value = Math.round((element.value / total) * 100);
    });
  }

  formatDataLabel(value: any) {
    return value + '%';
  }
}
