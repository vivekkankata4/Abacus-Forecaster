import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-nav-map',
  templateUrl: './nav-map.component.html',
  styleUrls: ['./nav-map.component.css']
})
export class NavMapComponent implements OnInit {

  @Input() dma: string;
  @Input() isZip: boolean;

  latLongList: {
    lat: number,
    lng: number
  };

  center: google.maps.LatLngLiteral;
  zoom: number;
  circleCenter: google.maps.LatLngLiteral;
  radius: number;
  markerPositions: google.maps.LatLngLiteral[];
  mapOptions: google.maps.MapOptions = {};
  mapCircleOptions = {};

  constructor() { }

  ngOnInit(): void {
    this.setPlot(this.dma);
  }

  ngOnChanges(): void {
    this.setPlot(this.dma);
  }

  async setPlot(dma_name: string) {
    let zipList: string[] = [];
    // if (this.isZip) {
    //   zipList = dma_name.split(',');
    // } else {
      const geocoding_url = `https://maps.googleapis.com/maps/api/geocode/json?address=${dma_name}&key=AIzaSyANJ6--XnhDRveINrEEuKw71kCv17xwUYs`;
      const res = await fetch(geocoding_url, { method: 'GET', headers: { 'Accept': 'application/json' } });
      const geoData = await res.json();
      const latLong = geoData['results'][0]['geometry']['location'];
      console.log('Lat Long: ', geoData['results']);
      this.latLongList = latLong;
   // }
    this.center = this.latLongList;
    this.circleCenter = this.latLongList;
    this.radius = 70000;
    this.zoom = 7;
    this.markerPositions = [this.center];

    this.mapOptions = {
      zoomControl: true,
      mapTypeControl: false,
      streetViewControl: false,
      fullscreenControl: false
    };

    this.mapCircleOptions = {
      fillColor: "2271cce7",
      strokeColor: "2271cce7",
      strokeOpacity: 1,
      strokeWeight: 1,
      fillOpacity: 0.2,
      clickable: false,
      draggable: false,
      editable: false,
      visible: true,
      zIndex: 1
    };
  }
}
