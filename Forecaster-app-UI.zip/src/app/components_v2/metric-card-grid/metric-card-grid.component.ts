import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-metric-card-grid',
  templateUrl: './metric-card-grid.component.html',
  styleUrls: ['./metric-card-grid.component.css']
})
export class MetricCardGridComponent implements OnInit {

  @Input() booked_imps: number;
  @Input() forecasted_imps: number;
  @Input() available_imps: number;
  @Input() monthly_imps: number;
  @Input() weekly_imps: number;
  @Input() daily_imps: number;
  @Input() household_num: number;
  @Input() total_population: number;

  constructor() {
    this.booked_imps = 0;
    this.forecasted_imps = 0;
    this.available_imps = 0;
    this.monthly_imps = 0;
    this.weekly_imps = 0;
    this.daily_imps = 0;
    this.household_num = 0;
    this.total_population = 0;
   }

  ngOnInit(): void {
  }

}
