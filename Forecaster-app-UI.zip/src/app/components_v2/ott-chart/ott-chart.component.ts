import { Component, OnInit, Input, AfterContentInit, AfterViewInit } from '@angular/core';
import { NgxChartsModule, Color, ScaleType, LegendPosition } from '@swimlane/ngx-charts';

@Component({
  selector: 'app-ott-chart',
  templateUrl: './ott-chart.component.html',
  styleUrls: ['./ott-chart.component.css']
})
export class OttChartComponent implements OnInit, AfterViewInit {
  @Input() ott_data: any[];
  public single: any[];
  view = [200, 400];

  colorScheme: Color = {
    name: 'Customer Usage',
    selectable: true,
    group: ScaleType.Ordinal,
    //domain: ['#B6C7A7', '#FFE7CF', '#A19DC4', '#E8B5D6', '#B2D3DB', '#FFE7CF', '#07D6F0', '#65A9EA', '#7B8FD9', '#9172BE', '#9F5399']
    //domain: ['#50C878', '#6CB4EE', '#93c47d', '#5CC2F2', '#00BFFF', '#7AEB95', '#8A7FE2', '#C1E1C1', '#6CB4EE']
    //domain: ['#5AA454', '#A10A28', '#C7B42C', '#AAAAAA',]
    //domain: ['#3F51B5', '#2196F3', '#00B862', '#AFDF0A', '#A7B61A', '#A838FD']

    //neutral
    //domain: ['#8DB89D', '#D3D39A', '#5268A0', '#ced2ba', '#B2B290', '#E0D8C3', '#9188B0', '#E5E5C2']

    //previous
    domain: ['#50C878', '#6CB4EE', '#93c47d', '#5CC2F2', '#00BFFF', '#7AEB95', '#8A7FE2', '#C1E1C1', '#6CB4EE']
  };

  showLegend: boolean = true;
  isDoughnut: boolean = false;
  legendTitle = '';
  legendPosition = LegendPosition.Right;

  constructor() {

  }

  ngOnInit(): void {
    if (this.ott_data && this.ott_data.length > 0) {
      console.log("I am in OTT");
      this.calculatePerentages();
      this.ott_data.sort((a, b) => (a.series[0].value > b.series[0].value ? -1 : 1));
      this.single = this.ott_data;
      Object.assign(this.single);
    }
  }

  ngOnChanges(): void {
    if (this.ott_data && this.ott_data.length > 0) {
      console.log("I am in OTT");
      this.calculatePerentages();
      this.ott_data.sort((a, b) => (a.series[0].value > b.series[0].value ? -1 : 1));
      this.single = this.ott_data;
      Object.assign(this.single);
    }
  }

  ngAfterViewInit(): void {
    ////console.log(document.getElementsByClassName("legend-label-text"));
    let legendLabels = document.getElementsByClassName("legend-label-text");
    if (legendLabels && legendLabels.length > 0) {
      for (let index = 0; index < legendLabels.length; index++) {
        let label: any = legendLabels[index];
        legendLabels[index].innerHTML = label.innerHTML.substring(0, label.innerHTML.indexOf("("));
      }
    }
  }

  calculatePerentages() {
    let total = 0;
    this.ott_data.forEach(element => {
      total = total + element.value;
    });

    this.ott_data.forEach(element => {
      if (element.name && element.name.indexOf("%") < 0) {
        element.name = element.name + "(" + Math.round((element.value / total) * 100) + "%)";
      }
      element.series = [{ value: Math.round((element.value / total) * 100) }];
    });
  }

  labelFormatting(label: any) {
    return label;
  }

}
