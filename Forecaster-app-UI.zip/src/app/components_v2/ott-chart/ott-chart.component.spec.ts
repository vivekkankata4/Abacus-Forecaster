import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OttChartComponent } from './ott-chart.component';

describe('OttChartComponent', () => {
  let component: OttChartComponent;
  let fixture: ComponentFixture<OttChartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OttChartComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OttChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
