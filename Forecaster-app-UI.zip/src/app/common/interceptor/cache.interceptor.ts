import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpResponse,
  HttpErrorResponse
} from '@angular/common/http';
import { Observable, catchError, of, tap, throwError } from 'rxjs';
import { environment } from 'src/environments/environment';
import { ApiUrlHelper } from '../helper/apiUrlHelper';
import { AuthService } from 'src/app/common/service/auth.service';

@Injectable()
export class CacheInterceptor implements HttpInterceptor {

  // store the response object
  cacheMap = new Map<string, HttpResponse<any>>();
  serverUrl: string = environment.serverUrl;

  constructor(private apiUrlHelper: ApiUrlHelper, private authService: AuthService) { }

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    // not cachable
    let authreq = request;
    if (!this.isRequestCachable(request)) {
      return next.handle(authreq).pipe(
        catchError((error: any) => {
            if (error instanceof HttpErrorResponse) {
                switch ((error as HttpErrorResponse).status) {
                    case 401:403
                      this.authService.logout();
                      break;
                }
            }
            return throwError(error);
        })
    ) as Observable<HttpEvent<any>>;
    }
    else {
      // request is cachable
      const url = request.url;
      // if the request is cached
      if (this.cacheMap.has(url)) {
        return of(this.cacheMap.get(url) as HttpResponse<any>);
      }
      else {
        return next.handle(request).pipe(
          tap(event => {
            if (event instanceof HttpResponse) {
              this.cacheMap.set(url, event);
            }
          })
        )
      }
    }
  }
  isRequestCachable(req: HttpRequest<any>): boolean {
    const urls = [
      this.apiUrlHelper.getApiUrl("dmas"),
      this.apiUrlHelper.getApiUrl("products"),
      this.apiUrlHelper.getApiUrl("segments"),
      this.apiUrlHelper.getApiUrl("publishers"),
      this.apiUrlHelper.getApiUrl("agencies"),
      this.apiUrlHelper.getApiUrl("advertisers"),
      this.apiUrlHelper.getApiUrl("master_publishers"),
      this.apiUrlHelper.getApiUrl("madhive_direct_approved"),
      this.apiUrlHelper.getApiUrl("freewheel_direct_approved")];

    if (req.url) {
      for (let i = 0; i < urls.length; i++) {
        if (req.url.includes(urls[i])) {
          return true;
        }
      }
    }
    return false;
  }

}


