import { Subject, BehaviorSubject } from "rxjs";

export class SharedDataHelper {

    constructor() { }

    private forecastPayload = new BehaviorSubject('');

    getForecastPayload = this.forecastPayload.asObservable();

    setForecastPayload(payload: string) {
        this.forecastPayload.next(payload);
    }
}
