import { Injectable } from "@angular/core";
import { environment } from "src/environments/environment";

@Injectable({
    providedIn: 'root'
})
export class ApiUrlHelper {
    serverUrl: string = environment.serverUrl;
    getApiUrl(key: string): string {
        let api_url = "";
        switch (key) {
            case "segments":
                api_url = "FA_DimensionAPI_Dev_2/getSegment";
                break;
            case "dmas":
                api_url = "FA_DimensionAPI_Dev_2/getDMA";
                break;
            case "zipcodes":
                api_url = "FA_DimensionAPI_Dev";
                break;
            case "products":
                api_url = "FA_DimensionAPI_Dev_2/getProduct";
                break;
            case "agencies":
                api_url = "FA_Approved_List_Feed_Dev/agencies";
                break;
            case "advertisers":
                api_url = "FA_Approved_List_Feed_Dev/advertisers";
                break;
            case "publishers":
                api_url = "FA_DimensionAPI_Dev_2/getPublisher";
                break;
            case "master_publishers":
                api_url = "FA_Publisher_Master_List_Dev";
                break;
            case "agency_advertiser":
                api_url = "FA_Approved_List_Feed_Dev_2/agency/advertisers";
                break;
            case "madhive_approved":
                api_url = "FA_Approved_List_Feed_Dev_2/agflow/agency/advertiser/ad_server/approved_list_group";
                break;
            case "advertiser_madhive":
                api_url = "FA_Approved_List_Feed_Dev_2/adflow/advertiser/ad_server/approved_list_group";
                break;
            case "agency_adv_publishers":
                api_url = "FA_Approved_List_Feed_Dev_2/agflow/agency/advertiser/ad_server/approved_list_group/publishers";
                break;
            case "advertiser_publishers":
                api_url = "FA_Approved_List_Feed_Dev_2/adflow/advertiser/ad_server/approved_list_group/publishers";
                break;
            case "advertiser_freewheel":
                api_url = "FA_Approved_List_Feed_Dev/adflow/";
                break;
            case "madhive_direct_approved":
                api_url = "FA_Approved_List_Feed_Dev_2/madhive/approved_list_group";
                break;
            case "freewheel_direct_approved":
                api_url = "FA_Approved_List_Feed_Dev_2/freewheel/approved_list_group";
                break;
            case "madhive_direct_publishers":
                api_url = "FA_Approved_List_Feed_Dev_2/madhive/approved_list_group/publishers";
                break;
            case "freewheel_direct_publishers":
                api_url = "FA_Approved_List_Feed_Dev_2/freewheel/approved_list_group/publishers";
                break;
            case "dma_forecast_impressions":
                api_url = "FA_DMA_Product_Pred_Dev_2";
                break;
            case "zip_booked_impressions":
                api_url = "FA_ZIP_Product_Bkd_Dev";
                break;
            case "zip_forecast_impressions":
                api_url = "FA_ZIP_Product_Pred_Dev";
                break;
            case "zip_seg_forecast_impressions":
                api_url = "FA_ZIP_Product_Segment_Pred_Dev";
                break;
            case "zip_pub_forecast_impressions":
                api_url = "FA_ZIP_Product_Publisher_Pred_Dev";
                break;
            case "zip_pub_seg_forecast_impressions":
                api_url = "FA_ZIP_Product_Publisher_Segment_Pred_Dev";
                break;
            case "save_forecast_zip":
                api_url = "FA_ZIP_Delivery_API_Dev_2/getDeliverybyZIP";
                break;
            case "save_forecast_dma":
                api_url = "FA_DMA_Delivery_API_Dev_2/getDeliverybyDMA";
                break;
            case "history_by_page":
                api_url = "FA_Get_Transactions_Dev/getHistByPage";
                break;
            case "history_by_user":
                api_url = "FA_Get_Transactions_Dev/getHistByUser";
                break;
            case "export_excel":
                api_url = "FA_Export_API_Dev_4/getFile";
                break;
            case "login":
                api_url = "FA_Auth_Login_API_Dev_2/getLogged";
                break;
            case "change_password":
                api_url = "FA_Auth_Login_API_Dev_2/setChangePass";
                break;
            case "valid_user":
                api_url = "FA_Auth_Login_API_Dev";
                break;
            default:
                break;
        }
        return this.serverUrl + api_url;
    }
}