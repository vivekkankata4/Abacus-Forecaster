export class ForecastHelper {
    getTodayDate(): any {
        var today = new Date();
        var dd = String(today.getDate()).padStart(2, '0');
        var mm = String(today.getMonth() + 1).padStart(2, '0');
        var yyyy = today.getFullYear();
        return yyyy + '-' + mm + '-' + dd;
    }

    getFormattedDate(campaignDate: string): any {
        var today = new Date(campaignDate);
        var dd = String(today.getDate()).padStart(2, '0');
        var mm = String(today.getMonth() + 1).padStart(2, '0');
        var yyyy = today.getFullYear();
        return yyyy + '-' + mm + '-' + dd;
    }

    getForcasterName(isZipped:boolean ,ziplist: any[], dma: string, product: string, segment: string, agency: string, advertiser: string, publisher: string, stDate: string, enddt: string): string {
        if (isZipped) {
            dma = ziplist[0].name;
        } else {
            dma = dma[0];
        }
        product = product[0];
        let forecastName: string = '';
        if (segment === '' || segment.length === 0) {
            forecastName = dma.toUpperCase() + '_' + product+'_'+stDate+'_'+enddt;
        }
        if (segment && segment.length > 0) {
            forecastName = dma.toUpperCase() + '_' + product + '_' + segment[0]+'_'+stDate+'_'+enddt;
        }
        if (agency !== '') {
            forecastName = forecastName + '_' + agency;
        }
        if (advertiser !== '') {
            forecastName = forecastName + '_' + advertiser;
        }
        if (publisher !== '') {
            forecastName = forecastName + '_' + publisher;
        }
        return forecastName;
    }
}