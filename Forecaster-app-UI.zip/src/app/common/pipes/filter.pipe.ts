import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'appFilter' })
export class FilterPipe implements PipeTransform {
  /**
   * Pipe filters the list of elements based on the search text provided
   *
   * @param items list of elements to search in
   * @param searchText search string
   * @returns list of elements filtered by search text or []
   */
  transform(items: any[], searchText: string): any[] {
    if (!items) {
      return [];
    }
    if (!searchText) {
      return items;
    }
    searchText = searchText.toLocaleLowerCase();
    return items.filter(it => {
      return Object.keys(it).some(
        k => {
            if (it[k] !== null && it[k] !== undefined && typeof it[k] === 'string') {
                return it[k].toLowerCase().includes(searchText.toLowerCase());
            }
        }
    );
    //     return (it).toString().toLowerCase().includes(searchText);
     });
     return items;
  }
}