import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'listFilter'
})
export class ListFilterPipe implements PipeTransform {
    transform(list: any, filterText: any): any {
        if (filterText && filterText !== 'ALL') {
            return list.filter((option: string) => option && option.toString().toLowerCase().includes(filterText.toLowerCase()));
            // return list.filter((item: { [x: string]: string; }) => {
            //     return Object.keys(item).some(
            //         k => {
            //             if (item[k] !== null && item[k] !== undefined && typeof item[k] === 'string') {
            //                 return item[k].toLowerCase().includes(filterText.toLowerCase());
            //             }
            //         }
            //     );
            // });
        }
        return list;
    }

}
