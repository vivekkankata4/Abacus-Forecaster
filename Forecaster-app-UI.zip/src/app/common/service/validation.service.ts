import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { MatDialog } from '@angular/material/dialog';
import { AlertDialogComponent } from '../../web/alert-dialog/alert-dialog.component';
import { DimensionService } from 'src/app/common/service/dimension.service';

@Injectable({
  providedIn: 'root'
})
export class ValidationService {
  private $showErrorMessage: BehaviorSubject<any> = new BehaviorSubject(undefined);
  public errorMessageObservable = this.$showErrorMessage.asObservable();
  private $goToErrorTab: BehaviorSubject<string> = new BehaviorSubject('');
  public goToErrorTabObservable = this.$goToErrorTab.asObservable();
  constructor(private dialog: MatDialog, private dimensionService: DimensionService) { }


  notifyError(msg: any, isSubmit?: boolean): void {
    this.$showErrorMessage.next({ messages: msg, isSubmit });
  }

  goToErrorTab(option: any): void {
    this.$goToErrorTab.next(option);
  }

  openAlertDialog(validationmsg: string) {
    const dialogRef = this.dialog.open(AlertDialogComponent, {
      data: {
        message: validationmsg
      },
      height: '100px',
    });
  }


}
