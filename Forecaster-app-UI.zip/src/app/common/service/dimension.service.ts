import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { ApiUrlHelper } from '../helper/apiUrlHelper';

@Injectable({
  providedIn: 'root'
})
export class DimensionService {
  headers: any = {
    'Accept': 'application/json',
    'Content-Type': 'application/json'
  };

  serverUrl: string = environment.serverUrl;

  constructor(private http: HttpClient, private apiUrlHelper: ApiUrlHelper) { }

  getDimensionData(): Observable<any> {
    const url = 'https://forecasteruitest3-bhjqm2qeka-ue.a.run.app/assets/json/segments.json';
    //const url = this.serverUrl + 'FA_DimensionAPI_Dev';
    return this.http.post<any>(url, "", { 'headers': this.headers, observe: 'response' });
  }

  getSegments(): Observable<any> {
    const url = this.apiUrlHelper.getApiUrl("segments");
    return this.http.get(url);
  }

  getDmas(): Observable<any> {
    //const url = this.serverUrl + 'FA_DimensionAPI_Dev';
    const url = this.apiUrlHelper.getApiUrl("dmas");
    return this.http.get(url);
  }

  getZIPCodes(data: any): Observable<any> {
    const url = this.apiUrlHelper.getApiUrl("zipcodes");
    return this.http.post<any>(url, data);
  }

  getProducts(): Observable<any> {
    const url = this.apiUrlHelper.getApiUrl("products");
    return this.http.get(url);
  }

  getAgency(): Observable<any> {
    //const url = this.serverUrl + 'FA_DimensionAPI_Dev';
    const url = this.apiUrlHelper.getApiUrl("agencies");
    return this.http.get(url);
  }

  getAdvertsisersNoLink(): Observable<any> {
    //const url = this.serverUrl + 'FA_DimensionAPI_Dev';
    const url = this.apiUrlHelper.getApiUrl("advertisers");
    return this.http.get(url);
  }

  getMasterPublishers(): Observable<any> {
    const url = this.apiUrlHelper.getApiUrl("master_publishers");
    return this.http.get(url);
  }

  getAdvertisement(data: any): Observable<any> {
    const url = this.apiUrlHelper.getApiUrl("agency_advertiser");
    return this.http.post<any>(url, data);
  }

  getMadhiveApproversList(data: any): Observable<any> {
    //https://us-central1-premion-audience-engagement.cloudfunctions.net/FA_Approved_List_Feed_Dev/Brivic Media/HM System ; Houston Methodist ; United Way/MADHIVE/approved_list_group
    //const url = this.serverUrl + 'FA_Approved_List_Feed_Dev_2';
    const url = this.apiUrlHelper.getApiUrl("madhive_approved");
    return this.http.post<any>(url, data);
  }

  getADVMadhiveList(data: any): Observable<any> {
    const url = this.apiUrlHelper.getApiUrl("advertiser_madhive");
    return this.http.post<any>(url, data);
  }

  getPublishers(data: any): Observable<any> {
    const url = this.apiUrlHelper.getApiUrl("agency_adv_publishers");
    return this.http.post<any>(url, data);
  }

  getADVPublishers(data: any): Observable<any> {
    const url = this.apiUrlHelper.getApiUrl("advertiser_publishers");
    return this.http.post<any>(url, data);
  }

  getADVFWPublishers(advertiser: string, approvedList: string): Observable<any> {
    const url = this.apiUrlHelper.getApiUrl("advertiser_freewheel");
    return this.http.get(url);
  }

  getMadDirectApproversList(): Observable<any> {
    const url = this.apiUrlHelper.getApiUrl("madhive_direct_approved");
    return this.http.get<any>(url);
  }

  getFWDirectApproversList(): Observable<any> {
    const url = this.apiUrlHelper.getApiUrl("freewheel_direct_approved");
    return this.http.get<any>(url);
  }

  getDirectMadhivePublishers(data: any): Observable<any> {
    const url = this.apiUrlHelper.getApiUrl("madhive_direct_publishers");
    return this.http.post<any>(url, data);
  }

  getDirectFWPublishers(data: any): Observable<any> {
    const url = this.apiUrlHelper.getApiUrl("freewheel_direct_publishers");
    return this.http.post<any>(url, data);
  }

  getForecastData(data: any): Observable<any> {
    const url = this.apiUrlHelper.getApiUrl("forecast_data");
    return this.http.post<any>(url, data);
  }

}
