import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, take } from 'rxjs';
import { environment } from 'src/environments/environment';
import { ApiUrlHelper } from '../helper/apiUrlHelper';
import { ApplicationErrorHandler } from 'src/app/error.handler';

@Injectable({
  providedIn: 'root'
})
export class ForecasterService {
  headers: any = {
    'Accept': 'application/json',
    'Content-Type': 'application/json'
  };

  serverUrl: string = environment.serverUrl;

  constructor(private http: HttpClient, private apiUrlHelper: ApiUrlHelper, private applicationErrorHandler: ApplicationErrorHandler) { }

  getZippedBookedImpressions(data: any): Promise<any> {
    return new Promise((resolve, reject) => {
      const bkdUrl = this.apiUrlHelper.getApiUrl("zip_booked_impressions");
      this.http.post<any>(bkdUrl, data, this.headers).pipe(take(1)).
      subscribe({
        next: (data) => resolve(data),
        error: (err) => reject(err),
      });
    });
  }

  getZippedForecasterImpressions(data: any): Promise<any> {
    return new Promise((resolve, reject) => {
      const predUrl = this.apiUrlHelper.getApiUrl("zip_forecast_impressions");
      this.http.post<any>(predUrl, data, this.headers).pipe(take(1)).
      subscribe({
        next: (data) => resolve(data),
        error: (err) => reject(err),
      });
    });
  }

  getZippedSegmentForecasterImpressions(data: any): Promise<any> {
    return new Promise((resolve, reject) => {
      const predUrl = this.apiUrlHelper.getApiUrl("zip_seg_forecast_impressions");
      this.http.post<any>(predUrl, data, this.headers).pipe(take(1)).
      subscribe({
        next: (data) => resolve(data),
        error: (err) => reject(err),
      });
    });
  }

  getZippedPublisherForecasterImpressions(data: any): Promise<any> {
    return new Promise((resolve, reject) => {
      const predUrl = this.apiUrlHelper.getApiUrl("zip_pub_forecast_impressions");
      this.http.post<any>(predUrl, data, this.headers).pipe(take(1)).
      subscribe({
        next: (data) => resolve(data),
        error: (err) => reject(err),
      });
    });
  }

  getZippedPub_SegForecasterImpressions(data: any): Promise<any> {
    return new Promise((resolve, reject) => {
      const predUrl = this.apiUrlHelper.getApiUrl("zip_pub_seg_forecast_impressions");
      this.http.post<any>(predUrl, data, this.headers).pipe(take(1)).
      subscribe({
        next: (data) => resolve(data),
        error: (err) => reject(err),
      });
    });
  }

  saveUserForecast(data: any, isZipped: boolean): Promise<any> {
    return new Promise((resolve, reject) => {
      let userForecast: string = '';
      //const userForecast = this.serverUrl + 'FA_Set_Transactions_Dev/setHistByUser';
      if (isZipped) {
        userForecast = this.apiUrlHelper.getApiUrl("save_forecast_zip");
      } else {
        userForecast = this.apiUrlHelper.getApiUrl("save_forecast_dma");
      }
      this.http.post<any>(userForecast, data, this.headers).pipe(take(1)).
      subscribe({
        next: (data) => resolve(data),
        error: (err: HttpErrorResponse) => {
          this.applicationErrorHandler.handleError(err);
        }
      });
    });
  }

  getUserForecastHistory(data: any): Observable<any> {
    //https://us-central1-premion-audience-engagement.cloudfunctions.net/FA_Get_Transactions_Dev/getHistByUser
    const userForecast = this.apiUrlHelper.getApiUrl("history_by_page");
    return this.http.post<any>(userForecast, data, this.headers)
  }

  exportExcel(data: any) {
    const url = this.apiUrlHelper.getApiUrl("export_excel");
    return this.http.post<any>(url, data, { headers: this.headers, responseType: 'arraybuffer' as 'json' });
  }
}
