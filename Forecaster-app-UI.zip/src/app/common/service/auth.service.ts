import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { environment } from "src/environments/environment";
import { ApiUrlHelper } from "../helper/apiUrlHelper";
import { Router } from '@angular/router';

@Injectable({
    providedIn: 'root'
})
export class AuthService {

    headers: any = {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
    };
    serverUrl: string = environment.serverUrl;

    constructor(private http: HttpClient, private apiUrlHelper: ApiUrlHelper,private router: Router) { }

    login(data: any): Observable<any> {
        const url = this.apiUrlHelper.getApiUrl("login");
        return this.http.post<any>(url, data, this.headers);
    }

    changePassword(data: any): Observable<any> {
        const url = this.apiUrlHelper.getApiUrl("change_password");
        return this.http.post<any>(url, data, this.headers);
    }

    getValidUser(data: any): Observable<any> {
        const url = this.apiUrlHelper.getApiUrl("valid_user");
        return this.http.post<any>(url, data, this.headers);
    }

    logout(): void {
        sessionStorage.clear();
        localStorage.clear();
        this.router.navigate(['/login']);
    }
}  