import { ErrorHandler, Injectable, Injector } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';

@Injectable({
    providedIn: 'root'
})

export class ApplicationErrorHandler implements ErrorHandler {

    constructor(private injector: Injector, private matbar: MatSnackBar) { }
    handleError(error: unknown) {
        this.matbar.open('Error was detected! We are already working on it', 'Close', {
            duration: 2000
        });
        console.warn(error);
        //this.validationService.openAlertDialog('Error was detected! We are already working on it');
    }
}
