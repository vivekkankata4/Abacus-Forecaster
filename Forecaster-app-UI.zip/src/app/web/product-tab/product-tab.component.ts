import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import { MAT_SELECT_CONFIG } from '@angular/material/select';
import { DimensionService } from 'src/app/common/service/dimension.service';

@Component({
  selector: 'app-product-tab',
  templateUrl: './product-tab.component.html',
  styleUrls: ['./product-tab.component.css'],
  providers: [
    {
      provide: MAT_SELECT_CONFIG,
      useValue: { overlayPanelClass: 'customClass' },
    },
  ],
})
export class ProductTabComponent implements OnInit {
  @Input() displayProducts: String = "";
  @Output() display = new EventEmitter<string>();
  @Output() previousButtonEvent = new EventEmitter();

  nextDisabled = true;
  public currentTab = '';
  public searchProduct = '';
  public selectedProduct = '';
  public productList = [];

  constructor(private dimensionService: DimensionService) { }

  ngOnInit(): void {
    this.getProductList();
    this.selectedProduct = (this.displayProducts && this.displayProducts != "") ? this.displayProducts.toString() : '';
    this.nextDisabled = this.selectedProduct !== '' ? false : true;
  }

  async getProductList(): Promise<void> {
    this.productList = [];
    this.dimensionService.getProducts().subscribe((products: any) => {
      if (products['data'] == undefined) {
        this.productList = [];
      } else {
        this.productList = products.data.map((obj: string) => {
          return obj;
        })
      }
    });
  }

  onNextBtnClick(tabName: string): void {
    this.currentTab = tabName;
    if (this.selectedProduct) {
      this.searchProduct = this.selectedProduct;
    }
    if (this.searchProduct === '') {
      this.searchProduct = 'No Products selected';
    }
    this.display.emit(this.searchProduct);
  }

  onPreviousBtnClick(tabName: string): void {
    this.currentTab = tabName;
    this.previousButtonEvent.emit('Vertical');
    if (tabName === 'Date') {
      this.currentTab = 'Date';
    }
  }

  selected(event: MatAutocompleteSelectedEvent): void {
    this.selectedProduct = event.option.viewValue;
  }

  selectionChange(option: any) {
    if (option[0].selected) {
      this.selectedProduct = option[0].value;
    } else {
      option[0].selected = false;
      this.selectedProduct = '';
    }
    this.nextDisabled = this.selectedProduct !== '' ? false : true;
  }
}
