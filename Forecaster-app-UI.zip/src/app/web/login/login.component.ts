import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/common/service/auth.service';
import { ValidationService } from 'src/app/common/service/validation.service';
import * as bcrypt from 'bcryptjs';
import { take } from 'rxjs';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  public errorMsg: string = '';
  public userlogin: string = '';
  public userpass: string = '';
  public isLoginScreen: boolean = true;
  public isValid: boolean = false;

  constructor(private router: Router, private validationService: ValidationService, private authService: AuthService) { }


  ngOnInit(): void { }

  async onUserLogin(): Promise<void> {
    if (this.userlogin === '' || this.userpass === '') {
      this.validationService.openAlertDialog('Login/Password must not be blank');
      sessionStorage.clear();
    } else if (this.userlogin !== '' && this.userpass !== '') {
      const salt = bcrypt.genSaltSync(10);
      let pass = bcrypt.hashSync(this.userpass, 10);
      const payload = {
        'USERNAME': this.userlogin,
        'USERPASS': pass
      };
      this.authService.login(payload).
      pipe(take(1)).
      subscribe((response: any) => {
      if (response && response.isExists && response.isFirst) {
          sessionStorage.setItem('userLogin', this.userlogin);
          if (response.isFirst === "1") {
            this.router.navigate(['/changePassword']);
          } else {
            this.router.navigate(['/list']);
          }
        } else {
          this.validationService.openAlertDialog('Please enter valid userName and Password');
          sessionStorage.clear();
        }
      }, (error: any) => {
        this.isValid = false;
        console.log(error);
      });
    }
  }
}

