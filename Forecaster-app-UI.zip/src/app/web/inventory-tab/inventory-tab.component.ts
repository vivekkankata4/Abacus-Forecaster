import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import { MatSelectionList } from '@angular/material/list';
import { Router } from '@angular/router';
import { map, Observable, startWith } from 'rxjs';
import { ForecastHelper } from 'src/app/common/helper/forecastHelper';
import { SharedDataHelper } from 'src/app/common/helper/sharedDataHelper';
import { DimensionService } from 'src/app/common/service/dimension.service';
import { ForecasterService } from 'src/app/common/service/forecaster.service';
import { ValidationService } from 'src/app/common/service/validation.service';

@Component({
  selector: 'app-inventory-tab',
  templateUrl: './inventory-tab.component.html',
  styleUrls: ['./inventory-tab.component.css']
})
export class InventoryTabComponent implements OnInit {
  @Output() display = new EventEmitter<string>();
  @Output() previousButtonEvent = new EventEmitter();
  @Input() forecastData: any = {};
  @ViewChild(MatSelectionList) pubs: MatSelectionList;
  isPubListNotEmpty: boolean = false;
  filteredAgency: Observable<string[]>;
  filteredAdv: Observable<string[]>;
  agencyControl = new FormControl();
  advControl = new FormControl();
  nextDisabled = false;
  public searchMasterPub = '';
  public searchAgency = '';
  public searchAdv = '';
  public searchMadhive = '';
  public searchPublisher = '';
  public searchFW = '';
  public selectedPio = '';
  public currentTab = '';
  public inventory_details: any = [];
  public newInventory = '';
  public isExistingInventory: boolean = true;
  public agencyList: string[] = [];
  public advertiserList: string[] = [];
  public publisherList: string[] = [];
  public masterPublisherList: string[] = [];
  public madhiveList: string[] = [];
  public freeWheelList: string[] = [];
  public selectedAgency = this.agencyList.length > 0 ? this.agencyList[0] : '';
  public selectedAdvertiser = this.advertiserList.length > 0 ? this.advertiserList[0] : '';
  public selectedpublisherList: string[] = [];
  public selectedMadhive = this.madhiveList.length > 0 ? this.madhiveList[0] : '';
  public selectedFW = this.freeWheelList.length > 0 ? this.freeWheelList[0] : '';
  public pioList: string[] = [];
  disableAgency: boolean = false;
  isLoading: boolean = false;

  constructor(
    private dimensionService: DimensionService, private router: Router,
    private forecasthelper: ForecastHelper, private forecasterService: ForecasterService,
    private sharedDataHelper: SharedDataHelper
    , private validationService: ValidationService) { }


  ngOnInit() {
    this.sharedDataHelper.setForecastPayload("");
    this.getAgency();
    this.getAdvertsisersNoLink();
    this.getMasterPublishers();
    this.getMadDirectApproversList();
    this.getFWDirectApproversList();
    //this.getAdvertiser();
    //this.getMadhiveList();
    //this.getFreeWheelList();
    //this.getPublisherList();
    this.filteredAgency = this.agencyControl.valueChanges.pipe(
      startWith(''), map((value: string) => this._filter(value))
    );
    this.filteredAdv = this.advControl.valueChanges.pipe(
      startWith(''), map((value: string) => this._advfilter(value))
    );
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this.agencyList.filter((option: string) => option.toString().toLowerCase().indexOf(filterValue) === 0);
  }

  private _advfilter(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this.advertiserList.filter((option: string) => option.toString().toLowerCase().indexOf(filterValue) === 0);
  }

  async getAgency(): Promise<void> {
    //this.dmaList = [];
    //'DIM': "AGENCY"
    let agency = this.dimensionService.getAgency().subscribe((result: any) => {
      if (result['AGENCIES'] == undefined) {
        //this.errorMsg = data['Error'];
        this.agencyList = [];
      } else {
        // this.errorMsg = "";
        this.agencyList = result.AGENCIES.map((obj: string) => {
          return obj;
        })
        this.agencyList = this.agencyList.filter(x => x);
      }
    });
  }

  async getAdvertsisersNoLink(): Promise<void> {
    this.advertiserList = [];
    let advertiser = this.dimensionService.getAdvertsisersNoLink().subscribe((result: any) => {
      if (result['ADVERTISERS'] == undefined) {
        //this.errorMsg = data['Error'];
        this.advertiserList = [];
      } else {
        // this.errorMsg = "";
        this.advertiserList = result.ADVERTISERS.map((obj: string) => {
          return obj;
        })
        this.advertiserList = this.advertiserList.filter(x => x);
      }
    });
  }

  async getMasterPublishers(): Promise<void> {
    this.masterPublisherList = [];
    let publisher = this.dimensionService.getMasterPublishers().subscribe((result: any) => {
      if (result['data'] == undefined) {
        //this.errorMsg = data['Error'];
        this.masterPublisherList = [];
      } else {
        // this.errorMsg = "";
        this.masterPublisherList = result.data.map((obj: string) => {
          return obj;
        })
        this.masterPublisherList = this.masterPublisherList.filter(x => x);
      }
    });
  }

  async getMadDirectApproversList(): Promise<void> {
    this.madhiveList = []
    let madhive = this.dimensionService.getMadDirectApproversList().subscribe((result: any) => {
      if (result['APPROVED_LIST_GROUP'] == undefined) {
        //this.errorMsg = data['Error'];
        this.madhiveList = []
      } else {
        // this.errorMsg = "";
        this.madhiveList = result.APPROVED_LIST_GROUP.map((obj: string) => {
          return obj;
        })
        this.madhiveList = this.madhiveList.filter(x => x);
      }
    });
  }

  async getFWDirectApproversList(): Promise<void> {
    this.freeWheelList = []
    let madhive = this.dimensionService.getFWDirectApproversList().subscribe((result: any) => {
      if (result['APPROVED_LIST_GROUP'] == undefined) {
        //this.errorMsg = data['Error'];
        this.freeWheelList = []
      } else {
        // this.errorMsg = "";
        this.freeWheelList = result.APPROVED_LIST_GROUP.map((obj: string) => {
          return obj;
        })
        this.freeWheelList = this.freeWheelList.filter(x => x);
      }
    });
  }

  async getAdvertiser(agency: string): Promise<void> {
    this.advertiserList = [];
    let advertiser = this.dimensionService.getAdvertisement({
      'AGENCY': agency
    }).subscribe((result: any) => {
      if (result['ADVERTISERS'] == undefined) {
        //this.errorMsg = data['Error'];
        this.advertiserList = [];
      } else {
        // this.errorMsg = "";
        this.advertiserList = result.ADVERTISERS.map((obj: string) => {
          return obj;
        })
        this.advertiserList = this.advertiserList.filter(x => x);
      }
    });
  }

  async getMadhiveList(agency: string, advertiser: string, adserver: string): Promise<void> {
    this.madhiveList = [];
    this.dimensionService.getMadhiveApproversList({
      'AGENCY': agency,
      'ADVERTISER': advertiser,
      'AD_SERVER': adserver
    }).subscribe((result: any) => {
      if (result['APPROVED_LIST_GROUP'] == undefined) {
        //this.errorMsg = data['Error'];
        this.madhiveList = [];
      } else {
        // this.errorMsg = "";
        if (adserver === 'MADHIVE') {
          this.madhiveList = result.APPROVED_LIST_GROUP.map((obj: string) => {
            return obj;
          })
          this.madhiveList = this.madhiveList.filter(x => x);
        } else if (adserver === 'FREEWHEEL') {
          this.freeWheelList = result.APPROVED_LIST_GROUP.map((obj: string) => {
            return obj;
          })
          this.freeWheelList = this.freeWheelList.filter(x => x);
        }
      }
    });
  }

  /* 
    async getFreewheelList(agency: string, advertiser: string): Promise<void> {
      this.freeWheelList = [];
      this.dimensionService.getFreewheelApproversList({
        'AGENCY': agency,
        'ADVERTISER': advertiser,
        'AD_SERVER': 'FREEWHEEL'
      }).subscribe((result: any) => {
        if (result['APPROVED_LIST_GROUP'] == undefined) {
          //this.errorMsg = data['Error'];
          this.freeWheelList = [];
        } else {
          // this.errorMsg = "";
          this.freeWheelList = result.APPROVED_LIST_GROUP.map((obj: string) => {
            return obj;
          })
          this.freeWheelList = this.freeWheelList.filter(x => x);
        }
      });
    }
    async getAGMadhiveList(agency: string): Promise<void> {
      this.madhiveList = [];
      this.dimensionService.getAGMadhiveList(agency).subscribe((result: any) => {
        if (result['APPROVED_LIST_GROUP'] == undefined) {
          //this.errorMsg = data['Error'];
          this.madhiveList = [];
        } else {
          // this.errorMsg = "";
          this.madhiveList = result.APPROVED_LIST_GROUP.map((obj: string) => {
            return obj;
          })
          this.madhiveList = this.madhiveList.filter(x => x);
        }
      });
    }
   */
  async getADVMadhiveList(advertiser: string, adserver: string): Promise<void> {
    this.madhiveList = [];
    this.dimensionService.getADVMadhiveList({
      'ADVERTISER': advertiser,
      'AD_SERVER': adserver
    }).subscribe((result: any) => {
      if (result['APPROVED_LIST_GROUP'] == undefined) {
        //this.errorMsg = data['Error'];
        this.madhiveList = [];
      } else {
        // this.errorMsg = "";
        if (adserver === 'MADHIVE') {
          this.madhiveList = result.APPROVED_LIST_GROUP.map((obj: string) => {
            return obj;
          })
          this.madhiveList = this.madhiveList.filter(x => x);
        } else if (adserver === 'FREEWHEEL') {
          this.freeWheelList = result.APPROVED_LIST_GROUP.map((obj: string) => {
            return obj;
          })
          this.freeWheelList = this.freeWheelList.filter(x => x);
        }
      }
    });
  }

  async getPublisherList(agency: string, advertiser: string, adserver: string, approvedList: string): Promise<void> {
    let publisher = this.dimensionService.getPublishers({
      'AGENCY': agency,
      'ADVERTISER': advertiser,
      'AD_SERVER': adserver,
      'APPROVED_LIST_GROUP': approvedList
    }).subscribe((result: any) => {
      if (result['PUBLISHERS'] == undefined) {
        //this.errorMsg = data['Error'];
        this.publisherList = [];
      } else {
        // this.errorMsg = "";
        if (!this.isPubListNotEmpty) {
          this.publisherList = result.PUBLISHERS.map((obj: string) => {
            return obj;
          });
          this.publisherList.splice(0, 0, 'All');
          this.isPubListNotEmpty = this.publisherList.length > 0 ? true : false;
        } else {
          let tempmadhivePubList = [];
          tempmadhivePubList = result.PUBLISHERS.map((obj: string) => {
            return obj;
          });
          this.publisherList = Array.from(new Set(this.publisherList.concat(tempmadhivePubList)));
        }
        this.publisherList = this.publisherList.filter((x, i, a) => a.indexOf(x) === i)
        this.selectAllPublishers();
      }
    });
  }

  async getADVPublisherList(advertiser: string, adserver: string, approvedList: string): Promise<void> {
    let publisher = this.dimensionService.getADVPublishers({
      'ADVERTISER': advertiser,
      'AD_SERVER': adserver,
      'APPROVED_LIST_GROUP': approvedList
    }).subscribe((result: any) => {
      if (result['PUBLISHERS'] == undefined) {
        //this.errorMsg = data['Error'];
        this.publisherList = [];
      } else {
        // this.errorMsg = "";
        if (!this.isPubListNotEmpty) {
          this.publisherList = result.PUBLISHERS.map((obj: string) => {
            return obj;
          });
          this.publisherList.splice(0, 0, 'All');
          this.isPubListNotEmpty = this.publisherList.length > 0 ? true : false;
        } else {
          let tempmadhivePubList = [];
          tempmadhivePubList = result.PUBLISHERS.map((obj: string) => {
            return obj;
          });
          this.publisherList = Array.from(new Set(this.publisherList.concat(tempmadhivePubList)));
        }
        this.publisherList = this.publisherList.filter((x, i, a) => a.indexOf(x) === i)
        this.selectAllPublishers();
      }
    });
  }

  async getDirectMadhivePublishers(adserver: string, approvedList: string): Promise<void> {
    let publisher = this.dimensionService.getDirectMadhivePublishers({
      'AD_SERVER': adserver,
      'APPROVED_LIST_GROUP': approvedList
    }).subscribe((result: any) => {
      if (result['PUBLISHERS'] == undefined) {
        //this.errorMsg = data['Error'];
        this.publisherList = [];
      } else {
        // this.errorMsg = "";
        if (!this.isPubListNotEmpty) {
          this.publisherList = result.PUBLISHERS.map((obj: string) => {
            return obj;
          });
          this.publisherList.splice(0, 0, 'All');
          this.isPubListNotEmpty = this.publisherList.length > 0 ? true : false;
        } else {
          let tempmadhivePubList = [];
          tempmadhivePubList = result.PUBLISHERS.map((obj: string) => {
            return obj;
          });
          this.publisherList = Array.from(new Set(this.publisherList.concat(tempmadhivePubList)));
        }
        this.publisherList = this.publisherList.filter((x, i, a) => a.indexOf(x) === i)
        this.selectAllPublishers();
      }
    });
  }

  async getDirectFWPublishers(adserver: string, approvedList: string): Promise<void> {
    let publisher = this.dimensionService.getDirectFWPublishers({
      'AD_SERVER': adserver,
      'APPROVED_LIST_GROUP': approvedList
    }).subscribe((result: any) => {
      if (result['PUBLISHERS'] == undefined) {
        //this.errorMsg = data['Error'];
        this.publisherList = [];
      } else {
        // this.errorMsg = "";
        if (!this.isPubListNotEmpty) {
          this.publisherList = result.PUBLISHERS.map((obj: string) => {
            return obj;
          });
          this.publisherList.splice(0, 0, 'All');
          this.isPubListNotEmpty = this.publisherList.length > 0 ? true : false;
        } else {
          let tempmadhivePubList = [];
          tempmadhivePubList = result.PUBLISHERS.map((obj: string) => {
            return obj;
          });
          this.publisherList = Array.from(new Set(this.publisherList.concat(tempmadhivePubList)));
        }
        this.publisherList = this.publisherList.filter((x, i, a) => a.indexOf(x) === i)
        this.selectAllPublishers();
      }
    });
  }

  onGenerateForecast(tabName: string): void {
    if (this.selectedpublisherList.indexOf("All") != -1) {
      this.selectedpublisherList.splice(this.selectedpublisherList.indexOf("All"), 1);
    }
    if (this.forecastData.SEGMENTS.indexOf("No Segments selected") != -1) {
      this.forecastData.SEGMENTS.splice(this.forecastData.SEGMENTS.indexOf("No Segments selected"), 1);
    }
    this.currentTab = tabName;
    //forecastData
    let productsList = this.forecastData.PRODUCTS.map((obj: string) => {
      return obj;
    });
    productsList = productsList.filter((x: string) => x);
    let dmaObj = this.forecastData.DMA.map((obj: string) => {
      return obj;
    });
    dmaObj = dmaObj.filter((x: string) => x);
    let ziplist: any[] = [];
    if (this.forecastData.ZIPS && this.forecastData.ZIPS.length > 0) {
      this.forecastData.ZIPS.forEach((aZipElement: { zipCodes: string; name: string; }) => {
        let aZip = aZipElement.zipCodes;
        let aZipCode = aZip.split(',').map((item: string) => item.trim());
        ziplist.push({ zipCodes: aZipCode, name: aZipElement.name });
      });
    }
    let segmentList = this.forecastData.SEGMENTS.map((obj: string) => {
      return obj;
    });
    segmentList = segmentList.filter((x: string) => x);
    let pubList: string = this.selectedpublisherList.length > 0 ? this.selectedpublisherList.toString() : '';
    let startDt = this.forecasthelper.getFormattedDate(this.forecastData.START_DATE);
    let endDt = this.forecasthelper.getFormattedDate(this.forecastData.END_DATE);
    let forecaster_name: string = this.forecasthelper.getForcasterName(ziplist.length > 0 ? true : false, ziplist, dmaObj, productsList, segmentList, this.searchAgency, this.searchAdv, pubList, startDt, endDt);
    if (this.forecastData.START_DATE === '' || this.forecastData.END_DATE === '' || dmaObj.length === 0) {
      this.validationService.openAlertDialog("StartDate,EndDate and DMA are mandatory");
    } else {
      const todayDate = this.forecasthelper.getTodayDate();
      let forecastRouteObj = {
        "USER_NAME": sessionStorage.getItem('userLogin'),
        "FORECAST_NAME": forecaster_name,
        "FORECAST_DATE": todayDate,
        'START_DATE': startDt,
        'END_DATE': endDt,
        'PRODUCTS': productsList.length > 0 ? productsList : [],
        'DMA': dmaObj.length > 0 ? dmaObj : [],
        'ZIPCODE_LIST': ziplist.length > 0 ? ziplist : [],
        'SEGMENTS': segmentList.length > 0 ? segmentList : [],
        'AGENCY': this.searchAgency,
        'ADVERTISER': this.searchAdv,
        // 'MADHIVE_LIST': this.searchMadhive,
        //'FREEWHEEL_LIST': this.searchFW,
        'PUBLISHERS': this.selectedpublisherList.length > 0 ? this.selectedpublisherList : [],
      }

      this.sharedDataHelper.setForecastPayload(JSON.stringify(forecastRouteObj));
      this.router.navigate(['/list']);
    }
  }

  onPreviousBtnClick(tabName: string): void {
    this.currentTab = tabName;
    this.previousButtonEvent.emit('Sales');
  }

  public checkInventoryVisited() {
    // reverse the value of property
    this.isExistingInventory = !this.isExistingInventory;
  }

  selectionPublisherChange(option: any): void {
    //this.selectedDmaList = [];
    if (option[0].selected && option[0].value === 'All') {
      this.selectAllPublishers();
    } else if (!option[0].selected && option[0].value === 'All') {
      this.deselectAllPublishers();
    } else if (option[0].selected && option[0].value !== 'All') {
      this.selectedpublisherList.push(option[0].value);
    } else {
      option[0].selected = false;
      const index: number = this.selectedpublisherList.indexOf(option[0].value);
    }
    this.nextDisabled = false;
  }

  selectionMasterChange(option: any): void {
    //this.selectedDmaList = [];
    if (option[0].selected && option[0].value === 'All') {
      this.selectAllPublishers();
    } else if (!option[0].selected && option[0].value === 'All') {
      this.deselectAllPublishers();
    } else if (option[0].selected && option[0].value !== 'All') {
      this.selectedpublisherList.push(option[0].value);
    } else {
      option[0].selected = false;
      const index: number = this.selectedpublisherList.indexOf(option[0].value);
    }
    this.nextDisabled = false;
  }

  selectAllPublishers(): void {
    this.pubs.selectAll();
    this.selectedpublisherList = Object.assign(this.selectedpublisherList, this.publisherList);
  }

  deselectAllPublishers(): void {
    this.pubs.deselectAll();
    this.selectedpublisherList = [];
  }

  selectedAGENCY(event: MatAutocompleteSelectedEvent): void {
    this.searchAgency = event.option.viewValue;
    this.searchAdv = '';
    this.searchMadhive = '';
    this.searchFW = '';
    this.publisherList = [];
    this.madhiveList = [];
    this.freeWheelList = [];
    if (this.searchAgency === "") {
      this.getAdvertsisersNoLink();
    } else {
      this.getAdvertiser(this.searchAgency);
    }
  }

  selectedADV(event: MatAutocompleteSelectedEvent): void {
    this.searchAdv = event.option.viewValue;
    if (this.searchAgency === "") {
      this.disableAgency = true;
      this.searchMadhive = '';
      this.searchFW = '';
      this.madhiveList = [];
      this.freeWheelList = [];
      this.publisherList = [];
      //this.publisherList.splice(0, 0, 'All');
      this.getADVMadhiveList(this.searchAdv, 'MADHIVE');
      this.getADVMadhiveList(this.searchAdv, 'FREEWHEEL');
      //this.getADVFreewheelList(this.searchAdv);
    } else if (this.searchAgency !== '' && this.searchAdv !== '') {
      this.getMadhiveList(this.searchAgency, this.searchAdv, 'MADHIVE');
      this.getMadhiveList(this.searchAgency, this.searchAdv, 'FREEWHEEL');
    }
  }

  selectedMadhiveOpt(event: MatAutocompleteSelectedEvent): void {
    this.searchMadhive = event.option.viewValue;
    if (this.searchAgency === '' && this.searchAdv !== '' && this.searchMadhive !== '') {
      this.getADVPublisherList(this.searchAdv, 'MADHIVE', this.searchMadhive);
    }
    else if (this.searchAgency !== '' && this.searchAdv !== '' && this.searchMadhive !== '') {
      this.getPublisherList(this.searchAgency, this.searchAdv, 'MADHIVE', this.searchMadhive);
    }
    else if (this.searchAgency === '' && this.searchAdv === '' && this.searchMadhive !== '') {
      this.getDirectMadhivePublishers('MADHIVE', this.searchMadhive);
    }
  }

  selectedFWOpt(event: MatAutocompleteSelectedEvent): void {
    this.searchFW = event.option.viewValue;
    if (this.searchAgency === '' && this.searchAdv !== '' && this.searchFW !== '') {
      this.getADVPublisherList(this.searchAdv, 'FREEWHEEL', this.searchFW);
    }
    else if (this.searchAgency !== '' && this.searchAdv !== '' && this.searchFW !== '') {
      this.getPublisherList(this.searchAgency, this.searchAdv, 'FREEWHEEL', this.searchFW);
    }
    else if (this.searchAgency === '' && this.searchAdv === '' && this.searchFW !== '') {
      this.getDirectFWPublishers('FREEWHEEL', this.searchFW);
    }
  }

  clearSearch(): void {
    this.searchAgency = '';
    this.searchAdv = '';
    this.searchMadhive = '';
    this.searchFW = '';
    this.madhiveList = [];
    this.freeWheelList = [];
    this.publisherList = [];
    this.getAdvertsisersNoLink();
  }

  clearADVSearch(): void {
    this.searchAdv = '';
    this.searchMadhive = '';
    this.searchFW = '';
    this.madhiveList = [];
    this.freeWheelList = [];
    this.publisherList = [];
  }

}

