import { AfterViewInit, Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSelectionList } from '@angular/material/list';
import { DimensionService } from 'src/app/common/service/dimension.service';
import { AlertDialogComponent } from '../alert-dialog/alert-dialog.component';

@Component({
  selector: 'app-vertical-tab',
  templateUrl: './vertical-tab.component.html',
  styleUrls: ['./vertical-tab.component.css']
})
export class VerticalTabComponent implements OnInit {

  @Input() displaySegments: String = "";
  @Output() display = new EventEmitter<string>();
  @Output() previousButtonEvent = new EventEmitter();
  @ViewChild("audience") audience: MatSelectionList;
  @ViewChild("segment") segment: MatSelectionList;
  nextDisabled = false;
  isAudienceDisabled = true;
  searchSegment = '';
  selectedAudienceList: string[] = [];
  selectedSegmentList: string[] = [];
  public audienceList: string[] = ['All', 'Automotive', 'Custom', 'Demographic', 'Entertainment', 'Finance',
    'Food & Dining', 'Sports'];
  public currentTab = '';
  public searchAudience = '';
  public needsSearch = false;
  public verticalList = [{ name: ' Automotive ', selected: false },
  { name: 'Custom', selected: false },
  { name: 'Demographic', selected: false },
  { name: 'Entertainment', selected: false },
  { name: 'Finance', selected: false },
  { name: 'Food & Dining', selected: false }];
  public segmentList: string[] = [];

  constructor(private dimensionService: DimensionService, private dialog: MatDialog) { }

  ngOnInit(): void {
    this.getSegments();
    this.selectedSegmentList = (this.displaySegments && this.displaySegments != "") ? this.displaySegments.split(",") : [];
    if (this.selectedSegmentList.length >= 2 && this.selectedSegmentList.indexOf("No Segments selected") != -1) { this.selectedSegmentList.splice(this.selectedSegmentList.indexOf("No Segments selected"), 1); }
    this.selectedSegmentList = this.selectedSegmentList.slice().sort();
  }

  ngAfterContentInit(): void {
    this.selectAllAudience();
    if (this.audience) {
      this.audience.setDisabledState(true);
    }
  }
  async getSegments(): Promise<void> {
    this.dimensionService.getSegments().subscribe((result: any) => {
      if (result['data'] == undefined) {
        //this.errorMsg = data['Error'];
        this.segmentList = [];
      } else {
        // this.errorMsg = "";
        this.segmentList = result.data.map((obj: string) => {
          let mapObj = obj ? obj.split(",") : "";
          return mapObj[0];
        });
        this.segmentList = this.segmentList.filter(x => x);
        //this.tempList = this.segmentList;
        this.segmentList.splice(0, 0, 'All');
      }
    });
  }

  selectionAudienceChange(option: any) {
    if (option[0].selected && option[0].value === 'All') {
      this.selectAllAudience();
    } else if (!option[0].selected && option[0].value === 'All') {
      this.deselectAudience();
    } else if (option[0].selected && option[0].value !== 'All') {
      this.selectedAudienceList.push(option[0].value);
      //to do api call pass audience and get segments
    } else {
      option[0].selected = false;
      const index: number = this.selectedAudienceList.indexOf(option[0].value);
      this.removeAudience(index);
    }
  }

  selectionSegmentChange(option: any) {
    if (option[0].selected && option[0].value === 'All') {
      this.selectAllSegment();
    } else if (!option[0].selected && option[0].value === 'All') {
      //this.deselectAudience();
      this.deSelectAllSegments();
    } else if (option[0].selected && option[0].value !== 'All') {
      this.selectedSegmentList.push(option[0].value);
    } else {
      option[0].selected = false;
      const index: number = this.selectedSegmentList.indexOf(option[0].value);
      this.removeSegment(index);
    }
    //this.nextDisabled = this.selectedSegmentList.length <= 2 ? false : true;
    if (this.selectedSegmentList.length >= 2 && this.selectedSegmentList.indexOf("No Segments selected") != -1) {
      this.selectedSegmentList.splice(this.selectedSegmentList.indexOf("No Segments selected"), 1);
    }
    if (this.selectedSegmentList.length > 2) {
      const index: number = this.selectedSegmentList.indexOf(option[0].value);
      if (option[0].value === 'All') {
        this.openAlertDialog(index, false);
      } else {
        this.openAlertDialog(index, true);
      }

    }
  }

  toggleSearchList(item: any, showList: boolean): void {
    this.searchAudience = item.name;
    this.needsSearch = showList;
  }

  onKeySearch(): void {
    this.needsSearch = true;
  }

  onNextBtnClick(tabName: string): void {
    this.currentTab = tabName;
    if (this.selectedSegmentList.length >= 2 && this.selectedSegmentList.indexOf("No Segments selected") != -1) {
      this.selectedSegmentList.splice(this.selectedSegmentList.indexOf("No Segments selected"), 1);
    }
    this.searchSegment = this.selectedSegmentList.join(',');
    if (this.searchSegment === '') {
      this.searchSegment = 'No Segments selected';
    }
    this.display.emit(this.searchSegment);

  }

  onPreviousBtnClick(tabName: string): void {
    this.currentTab = tabName;
    this.previousButtonEvent.emit('Geo');
    if (tabName === 'Date') {
      this.currentTab = 'Date';
    }
  }

  deselectAudience() {
    this.audience.deselectAll();
    this.selectedAudienceList = [];
  }

  selectAllAudience() {
    if (this.audience) {
      this.audience.selectAll();
      this.selectedAudienceList = Object.assign(this.selectedAudienceList, this.audienceList);
    }
  }

  removeAudience(i: number): void {
    this.selectedAudienceList.splice(i, 1);
  }

  deSelectAllSegments() {
    this.segment.deselectAll();
    this.selectedSegmentList = [];
  }

  selectAllSegment() {
    this.segment.selectAll();
    this.selectedSegmentList = Object.assign(this.selectedSegmentList, this.segmentList);
  }

  removeSegment(i: number): void {
    this.selectedSegmentList.splice(i, 1);
  }

  openAlertDialog(index: number, isAllSelected: boolean) {
    const dialogRef = this.dialog.open(AlertDialogComponent, {
      data: {
        message: 'Select Only 2 Segments',
        buttonText: {
          cancel: 'Close'
        }
      },
    });

    dialogRef.afterClosed().subscribe(() => {
      if (isAllSelected) {
        this.removeSegment(index);
      } else {
        this.deSelectAllSegments();
      }
    })
  }

  updateSegment(segment: string[]): string {
    return segment.toString();
  }

}