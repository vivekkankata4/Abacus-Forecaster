import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import { MatSelectionList } from '@angular/material/list';
import { Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { debounceTime, map, startWith, switchMap } from 'rxjs/operators';
import { DimensionService } from 'src/app/common/service/dimension.service';
import { ValidationService } from 'src/app/common/service/validation.service';

@Component({
  selector: 'app-geo-tab',
  templateUrl: './geo-tab.component.html',
  styleUrls: ['./geo-tab.component.css'],
})
export class GeoTabComponent implements OnInit {

  @Input() displayDMA: String = "";
  @Input() displayZIP: any[] = [];
  @Input() isZip: boolean = false;
  @Output() display = new EventEmitter<string>();
  @Output() displayList = new EventEmitter<any[]>();
  @Output() previousButtonEvent = new EventEmitter();
  @ViewChild(MatSelectionList) dmas: MatSelectionList;

  nextDisabled = true;
  zipList: any[] = [];
  selectedOptions: FormControl<string[] | null>;
  public isDMA: boolean = !this.isZip;
  filteredOptions: Observable<string[]>;
  public currentBtn = 'Dma';
  public currentTab = '';
  search = new FormControl();
  myControl = new FormControl();
  dmaControl = new FormControl();
  zippedGroup: any[] = [];
  selectedDmaList: string[] = [];
  tempList: string[] = [];
  public searchDma = '';
  public searchSelectedDma = '';
  public needsSearch = false;
  public dmaList: string[] = [];

  $search = this.search.valueChanges.pipe(
    startWith(null),
    debounceTime(200),
    switchMap((res: string) => {
      if (!res) return of(this.dmaList);
      res = res.toLowerCase();
      return of(
        this.dmaList.filter(x => x.toLowerCase().indexOf(res) >= 0)
      );
    })
  );

  constructor(private dimensionService: DimensionService, private validationService: ValidationService) { }

  async getDmas(): Promise<void> {
    //this.dmaList = [];
    let dmas = this.dimensionService.getDmas().subscribe((resp: any) => {
      if (resp['data'] == undefined) {
        //this.errorMsg = data['Error'];
        this.dmaList = [];
      } else {
        // this.errorMsg = "";
        this.dmaList = resp.data.map((obj: string) => {
          return obj;
        });
        this.dmaList = this.dmaList.filter(x => x);
        this.dmaList.splice(0, 0, 'All');
      }
      this.setDefaultSelection();
    });
  }

  async getZippedCluster(): Promise<void> {
    let dmas = this.dimensionService.getZIPCodes({
      'DIM': "ZIP"
    }).subscribe((res: any) => { });
  }

  ngOnInit() {
    this.isDMA = !this.isZip;
    this.getDmas();
  }

  setDefaultSelection() {
    if (this.displayDMA && this.displayDMA != "" && this.isDMA) {
      this.selectedDmaList = this.displayDMA.split(",");
    } else if (this.displayZIP && this.displayZIP.length > 0 && this.isZip) {
      this.displayZIP.forEach(element => {
        if (element.zipCodes !== "") {
          this.zippedGroup.push({ zipCodes: element.zipCodes });
        }
      });
    }
    if (this.isDMA) {
      this.nextDisabled = this.selectedDmaList.length > 0 ? false : true;
    } else {
      this.nextDisabled = this.zippedGroup.length > 0 ? false : true;
    }
  }

  private _filter(value: string): string[] {
    const filterValue = value.toString().toLowerCase();
    return this.dmaList.filter((option: string) => option.toString().toLowerCase().indexOf(filterValue) === 0);
  }

  onKeyDownEvent(event: any) {
    this.filteredOptions = this.myControl.valueChanges.pipe(
      startWith(''), map((value: string) => this._filter(value))
    );
  }

  toggleSearchList(item: any, showList: boolean): void {
    this.searchDma = item.name;
    this.needsSearch = showList;
  }

  onKeySearch(): void {
    this.needsSearch = true;
  }

  onButtonClick(dma: HTMLButtonElement, zip: HTMLButtonElement): void {
    dma.classList.add('btn-bgcolor');
    dma.classList.remove('btn-bgcolor');
  }

  onNextBtnClick(tabName: string): void {
    let isValid: boolean = false;
    if (this.isDMA) {
      if (this.selectedDmaList.length === 0) {
        //TO DO replace with matDialog
        /*  this.toastr.error('Please select atLeast one DMA', '', {
           positionClass: 'toast-top-right'
         }); */
      } else {
        this.searchDma = this.selectedDmaList.join(',');
        this.currentTab = tabName;
        this.display.emit(this.searchDma);
      }
    } else {
      let zipName = 'Ziplist';
      this.zipList = [];
      let invalidzips: string[] = [];
      let k = 1;
      this.zippedGroup.forEach(element => {
        let aZip = element.zipCodes;
        aZip = aZip.replace(/,*$/, '');
        aZip = aZip.replace(/[^a-zA-Z0-9,]/g, '');
        if (aZip !== "") {
          invalidzips = this.validateZipCodes(aZip);
          if (invalidzips.length === 0) {
            let zipCode = { zipCodes: aZip, name: zipName + ' ' + k }
            this.zipList.push(zipCode);
            k++;
          } else if (invalidzips.length > 0) {
            isValid = true;
            this.zipList = [];
            this.validationService.openAlertDialog("Zipcode should be number with 5 digits");
            //this.validationService.openAlertDialog("Zipcode should be number with 5 digits");
            //this.validationService.openAlertDialog("Given zips " + invalidzips.join(',') + " are either alphanumberic or less than 5 digits");
          }
        }
        //to do validation of zip codes should be numeric and should not be empty
        /*Below Code checks if list of zip codes are not empty */
        // if (aCode.zipCodes.length === 0) {
        //   this.toastr.error('ZipCodes names cannot be empty,duplicate and minimum length should be 5 digits');
        // }
      });
      if (!isValid) {
        this.displayList.emit(this.zipList);
      }
    };
  }

  isNumberic(aZipCode: string): any {
    const isNumber = (n: string | number): boolean =>
      !isNaN(parseFloat(String(n))) && isFinite(Number(n));
    return isNumber;
  }

  validateZipCodes(zipCodes: string): string[] {
    let invalidzips: string[] = [];
    let zipArray = zipCodes.split(',');
    zipArray.forEach(aZipElement => {
      aZipElement = aZipElement.replace(/[^a-zA-Z0-9]/g, '');
      if (aZipElement !== '' && isNaN(Number.parseFloat(aZipElement)) || isNaN(Number(aZipElement))) {
        invalidzips.push(aZipElement);
      } else if (aZipElement.length > 0 && aZipElement.length < 5) {
        invalidzips.push(aZipElement);
      }
    });
    return invalidzips;
  }

  onPreviousBtnClick(tabName: string): void {
    this.currentTab = tabName;
    this.previousButtonEvent.emit('Date');
    if (tabName === 'Date') {
      this.currentTab = 'Date';
    }
  }

  public checkDMAVisited() {
    this.isDMA = !this.isDMA;
    if (!this.isDMA && this.zippedGroup.length === 0) {
      this.addZippedCluster();
    }
    if (this.isDMA) {
      this.nextDisabled = this.selectedDmaList.length > 0 ? false : true;
    } else {
      this.nextDisabled = this.zippedGroup.length > 0 && this.zippedGroup[0].zipCodes !== "" ? false : true;
    }
  }

  selected(event: MatAutocompleteSelectedEvent): void {
    this.searchDma = event.option.viewValue;
  }

  addZippedCluster(): void {
    if (this.zippedGroup && this.zippedGroup.length >= 1 && this.zippedGroup[0].zipCodes === "") {
      this.validationService.openAlertDialog("ZipCodes cannot be empty");
    } else {
      this.zippedGroup.push({ zipCodes: "" });
    }
    this.nextDisabled = this.zippedGroup.length > 0 && this.zippedGroup[0].zipCodes !== "" ? false : true;
  }

  removeCluster(i: number): void {
    this.zippedGroup.splice(i, 1);
    this.nextDisabled = this.zippedGroup.length > 0 && this.zippedGroup[0].zipCodes !== "" ? false : true;
  }

  removeDma(i: number): void {
    this.selectedDmaList = this.selectedDmaList.splice(i, 1);
  }

  selectionChange(option: any) {
    if (option[0].selected && option[0].value === 'All') {
      this.selectAllDmas();
    } else if (!option[0].selected && option[0].value === 'All') {
      this.deselectDmas();
    } else if (option[0].selected && option[0].value !== 'All') {
      this.selectedDmaList.push(option[0].value);
      this.selectedDmaList.sort();
      if (this.selectedDmaList.length == this.dmaList.length - 1) {
        this.selectAllDmas();
      }
    } else {
      option[0].selected = false;
      const index: number = this.selectedDmaList.indexOf(option[0].value);
      this.selectedDmaList.splice(index, 1);
      if (this.selectedDmaList.indexOf("All") != -1) { this.selectedDmaList.splice(this.selectedDmaList.indexOf("All"), 1); }
    }
    if (this.isDMA) {
      this.nextDisabled = this.selectedDmaList.length > 0 ? false : true;
    } else {
      this.nextDisabled = this.zippedGroup.length > 0 ? false : true;
    }
  }

  selectedChange(option: any) {
    if (option[0].value === 'All') {
      this.deselectDmas();
    } else {
      option[0].selected = false;
      const index: number = this.selectedDmaList.indexOf(option[0].value);
      this.selectedDmaList.splice(index, 1);
      if (this.selectedDmaList.indexOf("All") != -1) { this.selectedDmaList.splice(this.selectedDmaList.indexOf("All"), 1); }
    }
    if (this.isDMA) {
      this.nextDisabled = this.selectedDmaList.length > 0 ? false : true;
    } else {
      this.nextDisabled = this.zippedGroup.length > 0 ? false : true;
    }
  }

  toggleSelection(item: any): void {
    item.selected = !item.selected;
  }

  deselectDmas() {
    this.dmas.deselectAll();
    this.selectedDmaList = [];
  }

  selectAllDmas() {
    this.dmas.selectAll();
    this.selectedDmaList = Object.assign([], this.dmaList);
    this.selectedOptions = new FormControl(this.selectedDmaList);
  }

  zipChange(zipInput: string) {
    this.nextDisabled = zipInput !== "" ? false : true;
  }
}
