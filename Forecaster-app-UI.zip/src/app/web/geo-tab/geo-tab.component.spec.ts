import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GeoTabComponent } from './geo-tab.component';

describe('GeoTabComponent', () => {
  let component: GeoTabComponent;
  let fixture: ComponentFixture<GeoTabComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GeoTabComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GeoTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
