import { Component, HostListener, OnInit } from '@angular/core';
import { ValidationService } from 'src/app/common/service/validation.service';


@Component({
  selector: 'app-tab-body',
  templateUrl: './tab-body.component.html',
  styleUrls: ['./tab-body.component.css']
})
export class TabBodyComponent implements OnInit {

  forecastDataObj: any = [];
  public startDate = "";
  public endDate = "";
  zips: any[] = [];
  public currentTab = 'Date';
  isZip: boolean = false;
  screenHeight: number;
  public tabItems = [
    { text: '<app-campaign-date></app-campaign-date>' },
    { text: '<app-product-tab></app-product-tab>' },
    { text: '<app-geo-tab></app-geo-tab>' },
    { text: '<app-vertical-tab></app-vertical-tab>' }
  ];

  constructor(private validationService: ValidationService) { }

  ngOnInit(): void {
    this.screenHeight = window.innerHeight;
  }

  @HostListener('window:resize')
  onResize() {
    this.screenHeight = window.innerHeight;
  }

  onTabValidation(tabName: string): string {
    let validationMessage = "";
    switch (tabName) {
      case "Geo": {
        if (this.startDate == '') {
          validationMessage = "StartDate and EndDate are mandatory";
          this.validationService.openAlertDialog(validationMessage);
          tabName = 'Date';
        }
        break;
      }
      case "Vertical": {
        if (this.startDate == '') {
          validationMessage = "StartDate and EndDate are mandatory";
          this.validationService.openAlertDialog(validationMessage);
          tabName = 'Date';
        } else if (this.geoName == '') {
          validationMessage = "DMA/Zip code is mandatory";
          this.validationService.openAlertDialog(validationMessage);
          tabName = 'Geo';
        }
        break;
      }
      case "Sales": {
        if (this.startDate == '') {
          validationMessage = "StartDate and EndDate are mandatory";
          this.validationService.openAlertDialog(validationMessage);
          tabName = 'Date';
        } else if (this.geoName == '') {
          validationMessage = "DMA/Zip code is mandatory";
          this.validationService.openAlertDialog(validationMessage);
          tabName = 'Geo';
        } else if (this.geoName !== '' && this.startDate !== '' && this.endDate !== '' && this.verticalName === '') {
          this.verticalName = 'No Segments selected';
        }
        break;
      }
      default: {
        //statements; 
        break;
      }
    }
    return tabName;
  }

  onTabClick(tabName: string): void {
    tabName = this.onTabValidation(tabName);
    let dmaList: string[] = this.geoNamesModified.split(',');
    let prodList: string[] = this.productName.split(',');
    let verticalList: string[] = this.verticalName.split(',');
    this.forecastDataObj = {
      'START_DATE': this.startDate,
      'END_DATE': this.endDate,
      'PRODUCTS': prodList,
      'SEGMENTS': verticalList,
      'DMA': dmaList,
      'ZIPS': this.zips
    };
    this.currentTab = tabName;
    if (tabName === 'Date') {
      this.currentTab = 'Date';
    }
    if (tabName === 'Inventory') {
      this.currentTab = 'Inventory';
    }
  }

  OnPreviousClick(previousTabName: string): void {
    this.onTabClick(previousTabName);
  }

  onDateDisplay(campaignDate: string) {
    this.startDate = campaignDate.split('^')[0];
    this.endDate = campaignDate.split('^')[1];
    this.onTabClick('Geo');
  }

  productName = "";
  onSalesDisplay(product: string) {
    this.productName = product;
    this.onTabClick('Inventory');
  }

  geoName = "";
  geoNamesModified = "";
  onGeoDisplay(geoList: string) {
    this.isZip = false;
    this.geoName = geoList;
    this.geoNamesModified = this.geoName.indexOf("All") > -1 ? this.geoName.replace("All,", "") : this.geoName;
    this.onTabClick('Vertical');
  }

  zipCodes: string = "";
  onGeoZip(zipList: any[]) {
    this.isZip = true;
    this.zips = zipList;
    this.zipCodes = zipList.map(x => x.zipCodes).toString();
    this.geoName = zipList.map(x => x.name).toString();
    this.geoNamesModified = this.geoName.indexOf("All") > -1 ? this.geoName.replace("All,", "") : this.geoName;
    this.onTabClick('Vertical');
  }

  verticalName = "";
  onVerticalDisplay(vertical: string) {
    this.verticalName = vertical;
    this.onTabClick('Sales');
  }

  ngOnDestroy() {
    this.tabItems = [];
  }

}
