import { Component, Input, OnInit } from '@angular/core';
import { Color, ScaleType } from '@swimlane/ngx-charts';

@Component({
  selector: 'app-daypart-chart',
  templateUrl: './daypart-chart.component.html',
  styleUrls: ['./daypart-chart.component.css']
})
export class DaypartChartComponent implements OnInit {

  @Input() daypart_data: any[];
  single: any[];
  multi: any[];
  showXAxis = true;
  showYAxis = true;
  showLegend = false;
  showXAxisLabel = true;
  xAxisLabel = 'Daypart';
  showYAxisLabel = true;
  yAxisLabel = 'Impressions';
  gradient = true;
  barPadding = 50;

  colorScheme: Color = {
    name: 'Customer Usage',
    selectable: true,
    group: ScaleType.Ordinal,
    domain: ['#5CC2F2']
  };

  constructor() { }

  ngOnInit(): void {
    if (this.daypart_data && this.daypart_data.length > 0) {
      this.single = this.daypart_data;
      Object.assign(this.single);
      this.calculatePerentages();
    }
  }

  ngOnChanges(): void {
    if (this.daypart_data && this.daypart_data.length > 0) {
      this.single = this.daypart_data;
      Object.assign(this.single);
      this.calculatePerentages();
    }
  }

  calculatePerentages() {
    let total = 0;
    this.single.forEach(element => {
      total = total + element.value;
    });

    this.single.forEach(element => {
      element.value = Math.round((element.value / total) * 100);
    });
  }

  formatDataLabel(value: any) {
    return value + '%';
  }
}
