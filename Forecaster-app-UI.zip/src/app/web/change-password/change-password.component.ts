import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { take } from 'rxjs';
import { AuthService } from 'src/app/common/service/auth.service';
import { ValidationService } from 'src/app/common/service/validation.service';


@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {
  public errorMsg: string = '';
  public oldpass: string = '';
  public newpass: string = '';
  public confirmpass: string = '';
  public userlogin: string | null = '';
  public isLoginScreen: boolean = true;
  public isValidoldPass: boolean = false;
  public isInValidNewPass: boolean = false;
  public isminNewPassValidation: boolean = false;

  constructor(private router: Router, private validationService: ValidationService, private authService: AuthService) { }

  ngOnInit(): void {
    this.userlogin = sessionStorage.getItem('userLogin');
  }

  onChangePasswordword(): void {
    if (this.userlogin !== '') {
      this.isValidoldPass = true;
      this.isminNewPassValidation = this.isStrong(this.newpass);
      if (!this.isminNewPassValidation) {
        this.isminNewPassValidation = true;
      } else {
        this.isminNewPassValidation = false;
        if (this.newpass === this.confirmpass) {
          this.isInValidNewPass = false;
          let user = sessionStorage.getItem('userLogin');
          const payload = {
            'USERNAME': user,
            'USERPASS': this.confirmpass
          };

          this.authService.changePassword(payload).pipe(take(1)).
      subscribe((response: any) => {
            if (response.message) {
              //sessionStorage.setItem('userLogin', this.userlogin);
              this.router.navigate(['/list']);
            }
            else {
              //to do error screen after 5 invalid attempts
              this.validationService.openAlertDialog('Login/Password must not be blank');
              sessionStorage.clear();
            }
          }, error => {
            this.isValidoldPass = false;
            console.log(error);
          });
        } else {
          this.isInValidNewPass = true;
          //this.validationService.openAlertDialog('Password and Confirm Password must be match.');
          console.log('confirm and new password doesnt match');
        }
      }
    }
  }

  public isStrong(pass: string): boolean {
    let hasMinLength = pass.trim().length >= 8;
    let hasNumber = /\d/.test(pass);
    let hasUpper = /[A-Z]/.test(pass);
    let hasLower = /[a-z]/.test(pass);
    // console.log('Num, Upp, Low', hasNumber, hasUpper, hasLower);
    return (hasMinLength && hasNumber && hasUpper && hasLower);
  }

}
