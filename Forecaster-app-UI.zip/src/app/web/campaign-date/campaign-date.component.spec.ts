import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CampaignDateComponent } from './campaign-date.component';

describe('CampaignDateComponent', () => {
  let component: CampaignDateComponent;
  let fixture: ComponentFixture<CampaignDateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CampaignDateComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CampaignDateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
