import { AfterContentInit, AfterViewInit, Component, EventEmitter, OnInit, Input, Output, Renderer2, ViewChild } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS } from '@angular/material-moment-adapter';
import { MatCalendar } from '@angular/material/datepicker';
import { NgbCalendar, NgbDate, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import * as _moment from 'moment';

const moment = _moment;
@Component({
  selector: 'app-campaign-date',
  templateUrl: './campaign-date.component.html',
  styleUrls: ['./campaign-date.component.css']
})
export class CampaignDateComponent implements OnInit, AfterContentInit, AfterViewInit {
  @Input() displayDate: String = "";
  nextDisabled = true;
  minDate!: moment.Moment;
  maxDate!: moment.Moment;
  @Output() display = new EventEmitter<string>();
  public currentTab = '';
  @Output()
  dateStartSelected: EventEmitter<moment.Moment> = new EventEmitter();

  @Output()
  dateEndSelected: EventEmitter<moment.Moment> = new EventEmitter();

  @Output()
  startMonthSelected: EventEmitter<moment.Moment> = new EventEmitter();

  @Output()
  endMonthSelected: EventEmitter<moment.Moment> = new EventEmitter();

  @ViewChild('calendar', { static: false })
  startcalendar: MatCalendar<Date>;
  startDate: Date;

  startfirstAt: Date = new Date();
  startsecondAt: Date = new Date();

  @ViewChild('endcalendar')
  endcalendar!: MatCalendar<Date>;
  endDate: Date;



  //   @ViewChild('calendar', { static: true })
  // calendar!: MatCalendar<moment.Moment>;

  constructor(private renderer: Renderer2, private calendar: NgbCalendar) { }

  setMinDate() {
    this.minDate = moment().add(-10, 'day');
  }

  changeDate() {
    const today = new Date();
    let currentMonth = new Date();
    let nextMonth = new Date();
    currentMonth.setDate(today.getDate() + 31);
    this.startDate = currentMonth;
    this.startcalendar._goToDateInView(currentMonth, "month");
  }

  setMaxDate() {
    this.maxDate = moment().add(10, 'day');
  }
  ngAfterContentInit() {
  }

  range = new FormGroup({
    start: new FormControl<Date | null>(null),
    end: new FormControl<Date | null>(null),
  });

  ngOnInit(): void {
    let tempDate = (this.displayDate && this.displayDate != "") ? this.displayDate.split("^") : [];
    if (tempDate[0] && tempDate[1]) {
      this.startDate = moment(tempDate[0]).toDate();
      this.endDate = moment(tempDate[1]).toDate();
      this.dateStartSelected.emit(moment(tempDate[0]));
      this.dateEndSelected.emit(moment(tempDate[1]));
      this.nextDisabled = false;

      let stDate = new Date(tempDate[0]);
      let enDate = new Date(tempDate[1]);
      this.fromDate = new NgbDate(stDate.getFullYear(), stDate.getMonth() + 1, stDate.getDate());
      this.toDate = new NgbDate(enDate.getFullYear(), enDate.getMonth() + 1, enDate.getDate());
      this.displayStartDate = this.fromDate;
    }

    /**Calculation to display only 4 months from Current Month -- Start */
    const currentMonth: NgbDate = this.calendar.getToday();
    currentMonth.day = 1;
    this.displayMinDate = currentMonth;

    const futureDate = this.calendar.getNext(this.calendar.getToday(), 'm', 4);
    const lastDateOfMonth = this.getLastDateOfMonth(futureDate);
    this.displayMaxDate = lastDateOfMonth;
    // this.displayMaxDate = { year: futureDate.year, month: futureDate.month, day: lastDayOfLastMonth };

    /**Calculation to display only 4 months from Current Month -- ENd*/

    let today = new Date();
    let month = today.getMonth() + 1; //next month
    let year = today.getUTCFullYear();
    let day = today.getDay();
    this.startfirstAt = new Date(year, month, day);
    let next = new Date();
    let nextmonth = next.getMonth() + 2; //next month
    let nextyear = next.getUTCFullYear();
    let nextday = next.getDay();
    this.startsecondAt = new Date(nextyear, nextmonth, nextday);
  }

  getLastDateOfMonth(date: NgbDateStruct): NgbDateStruct {
    const lastDayOfMonth = new Date(date.year, date.month, 0).getDate();
    return { year: date.year, month: date.month, day: lastDayOfMonth };
  }

  ngAfterViewInit() {
  }
  // this.setupArrowButtonListeners();

  
  startmonthSelected(date: moment.Moment, isStart: boolean) {
    if (isStart) {
      this.startMonthSelected.emit(date);
    }

  }

  endmonthSelected(date: moment.Moment, isStart: boolean) {
    this.endMonthSelected.emit(date);
  }

  dateStartChanged() {
    this.startcalendar.activeDate = this.startDate;
    this.validateDates();
    this.dateStartSelected.emit(moment(this.startDate));
  }

  dateEndChanged() {
    this.endcalendar.activeDate = this.endDate;
    this.validateDates();
    this.dateEndSelected.emit(moment(this.endDate));
    this.nextDisabled = false;
  }

  onNextBtnClick(tabName: string): void {
    this.currentTab = tabName;
    let startDD = moment(this.fromDate?.year + '-' + this.fromDate?.month + '-' + this.fromDate?.day).format('MM/DD/YYYY');
    let endDD = moment(this.toDate?.year + '-' + this.toDate?.month + '-' + this.toDate?.day).format('MM/DD/YYYY');
    this.display.emit("" + startDD + "^" + endDD);
  }

  onPreviousBtnClick(tabName: string): void {
    this.currentTab = tabName;
    if (tabName === 'Date') {
      this.currentTab = 'Date';
    }
  }

  isError: boolean = false;
  validateDates() {
    if (this.startDate && this.endDate) {
      if (this.endDate < this.startDate) {
        this.isError = true;
        this.nextDisabled = true;
      } else {
        this.isError = false;
        this.nextDisabled = false;
      }
    }
  }


  hoveredDate: NgbDate | null = null;

  fromDate: NgbDate;
  toDate: NgbDate | null = null;
  displayStartDate: NgbDate = this.calendar.getToday();
  displayMinDate: NgbDateStruct;
  displayMaxDate: NgbDateStruct;

  onDateSelection(date: NgbDate) {
    if (!this.fromDate && !this.toDate) {
      this.fromDate = date;
    } else if (this.fromDate && !this.toDate && date.after(this.fromDate)) {
      this.toDate = date;
    } else {
      this.toDate = null;
      this.fromDate = date;
    }
    this.dateStartSelected.emit(moment(this.fromDate?.year + '-' + this.fromDate?.month + '-' + this.fromDate?.day));
    this.dateEndSelected.emit(moment(this.toDate?.year + '-' + this.toDate?.month + '-' + this.toDate?.day));
    if (this.toDate?.after(this.fromDate)) {
      this.nextDisabled = false;
    } else {
      this.nextDisabled = true;
    }
  }

  isHovered(date: NgbDate) {
    return (
      this.fromDate && !this.toDate && this.hoveredDate && date.after(this.fromDate) && date.before(this.hoveredDate)
    );
  }

  isInside(date: NgbDate) {
    return this.toDate && date.after(this.fromDate) && date.before(this.toDate);
  }

  isRange(date: NgbDate) {
    return (
      date.equals(this.fromDate) ||
      (this.toDate && date.equals(this.toDate)) ||
      this.isInside(date) ||
      this.isHovered(date)
    );
  }
}
