import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-nav-map',
  templateUrl: './nav-map.component.html',
  styleUrls: ['./nav-map.component.css']
})
export class NavMapComponent implements OnInit {

  @Input() dma: string;
  @Input() isZip: boolean;

  latLongList: {
    lat: number,
    lng: number
  };

  center: google.maps.LatLngLiteral;
  zoom: number;
  circleCenter: google.maps.LatLngLiteral;
  radius: number;
  isMapLoaded: boolean = false;
  markerPositions: google.maps.LatLngLiteral[];
  mapOptions: google.maps.MapOptions = {
    zoomControl: true,
    mapTypeControl: false,
    streetViewControl: false,
    fullscreenControl: false
  };
  mapCircleOptions: {
    fillColor: "2271cce7",
    strokeColor: "2271cce7",
    strokeOpacity: 1,
    strokeWeight: 1,
    fillOpacity: 0.2,
    clickable: false,
    draggable: false,
    editable: false,
    visible: true,
    zIndex: 1
  };

  constructor() { }

  ngOnInit(): void {
    //this.setPlot(this.dma);
    this.initMap();
  }

  ngOnChanges(): void {
    // this.setPlot(this.dma);
    this.initMap();
  }

  async setPlot(dma_name: string) {
    this.isMapLoaded = true;
    const geocoding_url = `https://maps.googleapis.com/maps/api/geocode/json?address=${dma_name}&key=AIzaSyANJ6--XnhDRveINrEEuKw71kCv17xwUYs`;
    const res = await fetch(geocoding_url, { method: 'GET', headers: { 'Accept': 'application/json' } });
    const geoData = await res.json();
    if (geoData['results'] && geoData['results'].length > 0) {
      const latLong = geoData['results'][0]['geometry']['location'];
      this.latLongList = latLong;
      this.center = this.latLongList;
      this.circleCenter = this.latLongList;
      this.radius = 70000;
      this.zoom = 7;
      this.markerPositions = [this.center];

      this.mapCircleOptions = {
        fillColor: "2271cce7",
        strokeColor: "2271cce7",
        strokeOpacity: 1,
        strokeWeight: 1,
        fillOpacity: 0.2,
        clickable: false,
        draggable: false,
        editable: false,
        visible: true,
        zIndex: 1
      };
    }

  }

  map: any;
  zipCodes: string[] = [];

  initMap(): void {
    if (this.isZip) {
      let zipList = this.dma.split(',');
      this.zipCodes = zipList.map(String);
      this.zoom = 8;
      this.drawZipCodeCircles();
    } else {
      this.setPlot(this.dma);
    }
  }

  markers: any[] = [];
  bounds: Bounds = { north: 0, south: 0, east: 0, west: 0 };
  drawZipCodeCircles(): void {
    this.markers = [];
    const geocoder = new google.maps.Geocoder();
    let scaleSize: number = 4;
    if (this.zipCodes.length > 20) {
      scaleSize = 3;
    }
    for (const zipCode of this.zipCodes) {
      //let addComponents = zipCode+'&components=country:US';
      geocoder.geocode({ address: zipCode, componentRestrictions: { country: 'US' } }, (results: any, status: any) => {
        if (status === google.maps.GeocoderStatus.OK) {
          const location = results[0].geometry.location;
          this.markers.push({
            position: { lat: location.lat(), lng: location.lng() },
            label: zipCode,
            cursor: 'pointer',
            /* icon: {
              url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 10 10"><circle cx="5" cy="5" r="5" fill="#000000"  /></svg>'),
              scaledSize: new google.maps.Size(scaleSize, scaleSize),
              //Size(width:number, height:number, widthUnit?:string, heightUnit?:string)
            } */
          });
          this.updateBounds();
        }
      });
    }
  }

  updateBounds() {
    if (this.markers.length > 0) {
      const bounds = new google.maps.LatLngBounds();
      this.markers.forEach((marker) => {
        bounds.extend(marker.position);
      });
      const mapCenter = bounds.getCenter();
      const mapZoom = this.getZoomLevel(bounds);

      this.center = { lat: mapCenter.lat(), lng: mapCenter.lng() };
      this.zoom = mapZoom;
      this.isMapLoaded = true;
    }
  }

  getZoomLevel(bounds: google.maps.LatLngBounds): number {
    const GLOBE_WIDTH = 256; // Width of the Google Maps world in pixels at zoom level 0
    const ZOOM_MAX = 6; // Maximum zoom level

    const ne = bounds.getNorthEast();
    const sw = bounds.getSouthWest();

    const latDiff = Math.abs(ne.lat() - sw.lat());
    const lngDiff = Math.abs(ne.lng() - sw.lng());

    let zoomLat = Math.floor(Math.log2(GLOBE_WIDTH * 360 / latDiff));
    let zoomLng = Math.floor(Math.log2(GLOBE_WIDTH * 360 / lngDiff));

    const zoom = Math.min(zoomLat, zoomLng, ZOOM_MAX);

    return zoom;
  }
}

interface Bounds {
  north: number;
  south: number;
  east: number;
  west: number;
}
