import { AfterViewInit, Component, Input, OnInit } from '@angular/core';
import { Color, LegendPosition, ScaleType } from '@swimlane/ngx-charts';

@Component({
  selector: 'app-ott-chart',
  templateUrl: './ott-chart.component.html',
  styleUrls: ['./ott-chart.component.css']
})
export class OttChartComponent implements OnInit, AfterViewInit {
  @Input() ott_data: any[];
  public single: any[];
  view = [200, 400];

  colorScheme: Color = {
    name: 'Customer Usage',
    selectable: true,
    group: ScaleType.Ordinal,
    domain: ['#50C878', '#6CB4EE', '#93c47d', '#5CC2F2', '#00BFFF', '#7AEB95', '#8A7FE2', '#C1E1C1', '#6CB4EE']
  };

  showLegend: boolean = true;
  isDoughnut: boolean = false;
  legendTitle = '';
  legendPosition = LegendPosition.Right;

  constructor() { }

  ngOnInit(): void {
    if (this.ott_data && this.ott_data.length > 0) {
      this.calculatePerentages();
      this.ott_data.sort((a, b) => (a.series[0].value > b.series[0].value ? -1 : 1));
      this.single = this.ott_data;
      Object.assign(this.single);
    }
  }

  ngOnChanges(): void {
    if (this.ott_data && this.ott_data.length > 0) {
      this.calculatePerentages();
      this.ott_data.sort((a, b) => (a.series[0].value > b.series[0].value ? -1 : 1));
      this.single = this.ott_data;
      Object.assign(this.single);
    }
  }

  ngAfterViewInit(): void {
    let legendLabels = document.getElementsByClassName("legend-label-text");
    if (legendLabels && legendLabels.length > 0) {
      for (let index = 0; index < legendLabels.length; index++) {
        let label: any = legendLabels[index];
        legendLabels[index].innerHTML = label.innerHTML.substring(0, label.innerHTML.indexOf("("));
      }
    }
  }

  calculatePerentages() {
    let total = 0;
    this.ott_data.forEach(element => {
      total = total + element.value;
    });

    this.ott_data.forEach(element => {
      if (element.name && element.name.indexOf("%") < 0) {
        element.name = element.name + "(" + Math.round((element.value / total) * 100) + "%)";
      }
      element.series = [{ value: Math.round((element.value / total) * 100) }];
    });
  }

  labelFormatting(label: any) {
    return label;
  }

}
