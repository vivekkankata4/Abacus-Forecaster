import { Component, OnInit, Input } from '@angular/core';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { MatTableDataSource } from '@angular/material/table';
import { BehaviorSubject } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { formatNumber } from '@angular/common';
import { ForecasterService } from 'src/app/common/service/forecaster.service';

@Component({
  selector: 'app-forecast-table',
  templateUrl: './forecast-table.component.html',
  styleUrls: ['./forecast-table.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})

export class ForecastTableComponent implements OnInit {
  private errorMessage?: string;
  public isZip: boolean = false;
  public isSummaryScreen = true;
  isTableExpanded = false;
  //ZIPS
  public dmaList: { name: string, isSelected: boolean }[] = [];
  public zipCodeList: { name: string, isSelected: boolean, zipCodes: string }[] = [];
  public selectedDma: string;
  daypart_data: any[];
  ott_data: any[];
  public COLUMNS_SCHEMA: {
    key: string;
    type: string;
    label: string;
  }[] = [
      { key: "forecast_date", type: "text", label: "Forecast Date" },
      { key: "product", type: "text", label: "Product" },
      { key: "dma", type: "text", label: "Geo" },
      { key: "stDate", type: "text", label: "Start Date" },
      { key: "endDate", type: "text", label: "End Date" },
      { key: "capacity", type: "number", label: "Capacity" },
      { key: "reserved", type: "number", label: "Reserved" },
      { key: "available", type: "number", label: "Available" },
      { key: "sales_planner", type: "text", label: "Sales Planner" },
      { key: "status", type: "text", label: "Status" }
    ];

  public rowData: any[];

  dataForecastList = new MatTableDataSource();
  displayedForecastColumnsList: string[] = ['forecast_date', 'product', 'dma', 'stDate', 'endDate', 'capacity', 'reserved', 'available', 'sales_planner', 'status'];

  public agency_name: string;
  public advertiser_name: string;
  public product: string;
  public geo_list: string[] = [];
  public zip_list: any[] = [];
  public segment_names: string[] = [];
  public publisher_names: string[] = [];
  public start_date: string = '';
  public end_date: string = '';
  public booked_imps: number = 0;
  public forecasted_imps: number = 0;
  public available_imps: number = 0;
  public monthly_imps: number = 0;
  public weekly_imps: number = 0;
  public daily_imps: number = 0;
  public household_nums: number = 0;
  public total_population: number = 0;
  public dma: string;
  isGenerateForecast: boolean = false;
  constructor(private route: ActivatedRoute, private forecasterService: ForecasterService) { }

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      if (params['forecastData']) {
        this.isGenerateForecast = true;
        let data = JSON.parse(params['forecastData']);
        //console.log('Got param: ', data);
        this.agency_name = data.AGENCY;
        this.advertiser_name = data.ADVERTISER;
        this.product = data.PRODUCTS[0];
        this.geo_list = data.DMA;
        this.zip_list = data.ZIPS;
        this.segment_names = data.SEGMENTS;
        this.publisher_names = data.PUBLISHERS;
        //(data.START_DATE).format('-MM-YYYY');
        this.start_date = data.START_DATE;
        this.end_date = data.END_DATE;
        //this.daypartData(this.geo_list);
        // if (this.geo_list && data.ZIPS.length === 0) {
        //   this.daypartData(this.geo_list);
        //   this.ottData(this.geo_list);
        // } else if (this.zip_list[0].zipCodes && this.zip_list[0].zipCodes.length > 0) {
        //   let zipCode = this.zip_list[0].zipCodes;
        //   this.daypartZipData(zipCode);
        //   this.ottZipData(zipCode);
        // }

        //this.daypartData(this.geo_list);
        //this.ottData(this.geo_list);
        //this.zipProd_data(this.product,this.start_date,this.end_date,resultArray);
      }
    });
    if (!this.isGenerateForecast) {
      this.rowData = [];
    } else {
      var today = new Date();
      var dd = String(today.getDate()).padStart(2, '0');
      var mm = String(today.getMonth() + 1).padStart(2, '0');
      var yyyy = today.getFullYear();
      const todayDate = yyyy + '-' + mm + '-' + dd;
      if (this.geo_list && this.zip_list.length === 0) {
        this.fetchDmaFilterList();
      } else if (this.zip_list[0].zipCodes && this.zip_list[0].zipCodes.length > 0) {
        this.fetchZipFilterList();
      }
      this.rowData = [{
        Id: '1',
        forecast_date: todayDate,
        product: this.product,
        dma: this.selectedDma,
        advertiser: this.advertiser_name,
        stDate: this.start_date,
        endDate: this.end_date,
        capacity: 0,
        reserved: 0,
        available: 0,
        monthly: 0,
        weekly: 0,
        daily: 0,
        sales_planner: 'Guest User',
        status: 'Processing',
        isExpanded: false
      }];

      this.dataForecastList.data = this.rowData;
      //this.onDMAFetchData(this.selectedDma);
      if (this.zip_list.length > 0) {
        this.onZipFetchData(this.selectedDma);
      } else {
        this.onDMAFetchData(this.selectedDma);
      }
    }
  }

  toggleTableRows() {
    console.log(this.daypart_data);
    console.log(this.ott_data);
    this.isTableExpanded = !this.isTableExpanded;
  }

  async onZipFetchData(dma: string) {
    console.log("dma--->" + dma);
    this.resetMetricData();
    this.isZip = true;

    var tempImps: number[];
    let zipCode = dma && dma !== '' ? dma : this.zip_list[0].zipCodes;
    console.log("test zipcode" + zipCode.split(","));

    this.daypartZipData(zipCode.split(","));
    this.ottZipData(zipCode.split(","));

    //let resultArray = zipCode.split(',').map(function(zipCode: any){return Number(zipCode);});

    if (this.publisher_names.length === 0 && this.segment_names.length === 0) {
      tempImps = await this.zipProd_data(this.product, '', this.start_date, this.end_date, zipCode);
      this.booked_imps = Math.round(tempImps[0])
      this.forecasted_imps = Math.round(tempImps[1])
      this.available_imps = Math.round(tempImps[1] - tempImps[0]);
      this.calculateDifference();

      // let diffDays:any = this.calculateDays(new Date(this.start_date),new Date(this.end_date));
      // let diffMonth:any = this.differenceInMonths(new Date(this.start_date),new Date(this.end_date));
      // let diffweeks:any = Math.floor(diffDays/7);
      // console.log("diffDays--->"+diffDays);
      // console.log("diffMonth--->"+diffMonth);
      // console.log("diffweeks--->"+diffweeks);
      // //let diffDays:any = Math.floor((this.start_date - this.end_date) / (1000 * 60 * 60 * 24));
      // this.monthly_imps = Math.round(this.available_imps / 90);
      // this.weekly_imps = Math.round(this.available_imps / 12);
      // this.daily_imps = Math.round(this.available_imps / 120);
    }


    else if (this.publisher_names.length === 0 && this.segment_names.length > 0) {
      tempImps = await this.zipProdSeg_data(this.product, this.segment_names, this.start_date, this.end_date, zipCode);
      this.booked_imps = Math.round(tempImps[0])
      this.forecasted_imps = Math.round(tempImps[1])
      this.available_imps = Math.round(tempImps[1] - tempImps[0]);
      this.calculateDifference();
    }

    else if (this.publisher_names.length > 0 && this.segment_names.length > 0) {
      tempImps = await this.zipProdPubSeg_data(this.product, this.publisher_names, this.segment_names, this.start_date, this.end_date, zipCode);
      this.booked_imps = Math.round(tempImps[0])
      this.forecasted_imps = Math.round(tempImps[1])
      this.available_imps = Math.round(tempImps[1] - tempImps[0]);
      this.calculateDifference();
    }

    else if (this.publisher_names.length > 0 && this.segment_names.length == 0) {
      tempImps = await this.zipProdPub_data(this.product, this.publisher_names, this.start_date, this.end_date, zipCode);
      this.booked_imps = Math.round(tempImps[0])
      this.forecasted_imps = Math.round(tempImps[1])
      this.available_imps = Math.round(tempImps[1] - tempImps[0]);
      this.calculateDifference();
    }


    this.dma = zipCode;
    let totals = await this.getHouseholds(zipCode, false);
    this.household_nums = totals.TOTAL_MARKET_HOUSEHOLDS;
    this.total_population = totals.TOTAL_OTT_HOUSEHOLDS;


    this.rowData[0]['capacity'] = String(formatNumber(this.forecasted_imps, 'en-US', '1.0'));
    this.rowData[0]['reserved'] = String(formatNumber(this.booked_imps, 'en-US', '1.0'));
    this.rowData[0]['available'] = String(formatNumber(this.available_imps, 'en-US', '1.0'));
    this.rowData[0]['status'] = "Completed";
  };

  async onDMAFetchData(dma: string) {
    this.resetMetricData();
    var tempImps: number[];

    let selectedDma = dma && dma !== '' ? dma : this.geo_list[0];
    this.daypartData([selectedDma]);
    this.ottData([selectedDma]);

    if (this.publisher_names.length == 0 && this.segment_names.length > 0) {
      tempImps = await this.dmaProdSeg_data(dma, this.product, this.segment_names, this.start_date, this.end_date);
      this.booked_imps = Math.round(tempImps[0])
      this.forecasted_imps = Math.round(tempImps[1])
      this.available_imps = Math.round(tempImps[1] - tempImps[0]);
      this.calculateDifference();
      //this.monthly_imps = Math.round(this.available_imps / 90);
      //this.weekly_imps = Math.round(this.available_imps / 12);
      //this.daily_imps = Math.round(this.available_imps / 120);
    }

    else if (this.publisher_names.length > 0 && this.segment_names.length > 0) {
      tempImps = await this.dmaProdPubSeg_data(dma, this.product, this.publisher_names, this.segment_names, this.start_date, this.end_date);
      this.booked_imps = Math.round(tempImps[0])
      this.forecasted_imps = Math.round(tempImps[1])
      this.available_imps = Math.round(tempImps[1] - tempImps[0]);
      this.calculateDifference();
      //this.monthly_imps = Math.round(this.available_imps / 90);
      //this.weekly_imps = Math.round(this.available_imps / 12);
      //this.daily_imps = Math.round(this.available_imps / 120);
    }

    else if (this.publisher_names.length == 0 && this.segment_names.length == 0) {
      tempImps = await this.dmaProd_data(dma, this.product, this.start_date, this.end_date);
      this.booked_imps = Math.round(tempImps[0]);
      this.forecasted_imps = Math.round(tempImps[1]);
      this.available_imps = Math.round(tempImps[1] - tempImps[0]);
      this.calculateDifference();
    }

    else if (this.publisher_names.length > 0 && this.segment_names.length == 0) {
      tempImps = await this.dmaProdPub_data(dma, this.product, this.publisher_names, this.start_date, this.end_date);
      this.booked_imps = Math.round(tempImps[0])
      this.forecasted_imps = Math.round(tempImps[1])
      this.available_imps = Math.round(tempImps[1] - tempImps[0]);
      this.calculateDifference();
      // this.monthly_imps = Math.round(this.available_imps / 90);
      // this.weekly_imps = Math.round(this.available_imps / 12);
      // this.daily_imps = Math.round(this.available_imps / 120);
    }
    this.dma = dma;
    let totals = await this.getHouseholds(dma, true);
    this.household_nums = totals.TOTAL_MARKET_HOUSEHOLDS;
    this.total_population = totals.TOTAL_OTT_HOUSEHOLDS;

    this.rowData[0]['capacity'] = String(formatNumber(this.forecasted_imps, 'en-US', '1.0'));
    this.rowData[0]['reserved'] = String(formatNumber(this.booked_imps, 'en-US', '1.0'));
    this.rowData[0]['available'] = String(formatNumber(this.available_imps, 'en-US', '1.0'));
    this.rowData[0]['status'] = "Completed";
  };

  fetchDmaFilterList(): void {
    if (this.geo_list && this.geo_list.length == 0) {
      this.dmaList.push({
        name: 'None',
        isSelected: true
      })
      this.selectedDma = 'None'
    }
    else if (this.geo_list && this.geo_list.length > 0) {
      this.selectedDma = this.geo_list.sort()[0];
      this.geo_list.forEach((element) => {
        const jsonObj = { name: element, isSelected: false };
        this.dmaList.push(jsonObj);
      });
    };
  };

  fetchZipFilterList(): void {
    if (this.zip_list && this.zip_list.length == 0) {
      this.zipCodeList.push({
        name: 'None',
        isSelected: true,
        zipCodes: '0'
      })
      this.selectedDma = 'None'
    }
    else if (this.zip_list && this.zip_list.length > 0) {
      this.selectedDma = this.zip_list[0].zipCodes;
      this.zip_list.forEach((element) => {
        const jsonObj = { name: element.name, zipCodes: element.zipCodes, isSelected: false };
        this.zipCodeList.push(jsonObj);
      });
    };
  };

  async getHouseholds(dma: string, isDma: boolean): Promise<any> {
    var households = 0;
    try {
      //const householdUrl = 'https://us-central1-premion-audience-engagement.cloudfunctions.net/FA_Households_Dev';
      const householdUrl = isDma ? 'https://us-central1-premion-audience-engagement.cloudfunctions.net/FA_Households_Dev_2/dmahousehold' :
        'https://us-central1-premion-audience-engagement.cloudfunctions.net/FA_Households_Dev_2/ziphousehold';
      const headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      };
      const payload = isDma ? {
        'DMA': dma
      } : { 'ZIPCODES': dma.split(',') };
      const res = await fetch(householdUrl, { method: 'POST', headers: headers, body: JSON.stringify(payload) });
      const data = await res.json();
      return data;
    }

    catch {
      return households
    }
  };

  async dmaProd_data(dma: string,
    product: string,
    start_date: string,
    end_date: string): Promise<number[]> {

    const paramBkd = {
      'DMA': [dma],
      'PRODUCTS': [product],
      'SEGMENTS': [],
      'START_DATE': start_date,
      'END_DATE': end_date
    };

    const paramPred = {
      'DMA': [dma],
      'PRODUCTS': [product],
      'START_DATE': start_date,
      'END_DATE': end_date
    };

    const headers = {
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    };

    const bkdUrl = 'https://us-central1-premion-audience-engagement.cloudfunctions.net/FA_DMA_Product_Bkd_Dev';
    const predUrl = 'https://us-central1-premion-audience-engagement.cloudfunctions.net/FA_DMA_Product_Pred_Dev_2';

    const resBkd = await fetch(bkdUrl, { method: 'POST', headers: headers, body: JSON.stringify(paramBkd) });
    const dataBkd = await resBkd.json();
    const bkdImps = dataBkd["data"]["data"][0][0];

    const resPred = await fetch(predUrl, { method: 'POST', headers: headers, body: JSON.stringify(paramPred) });
    const dataPred = await resPred.json();
    const predImps = dataPred["data"]["data"][0][0];

    return [bkdImps, predImps]
  };

  async dmaProdSeg_data(dma: string,
    product: string,
    segments: string[],
    start_date: string,
    end_date: string): Promise<number[]> {

    const paramBkd = {
      'DMA': [dma],
      'PRODUCTS': [product],
      'SEGMENTS': segments,
      'START_DATE': start_date,
      'END_DATE': end_date
    };

    const paramPred = {
      'DMA': [dma],
      'PRODUCTS': [product],
      'SEGMENTS': segments,
      'START_DATE': start_date,
      'END_DATE': end_date
    };

    const headers = {
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    };

    const bkdUrl = 'https://us-central1-premion-audience-engagement.cloudfunctions.net/FA_DMA_Product_Bkd_Dev';
    const predUrl = 'https://us-central1-premion-audience-engagement.cloudfunctions.net/FA_DMA_Product_Segment_Pred_Dev_2';

    const resBkd = await fetch(bkdUrl, { method: 'POST', headers: headers, body: JSON.stringify(paramBkd) });
    const dataBkd = await resBkd.json();
    const bkdImps = dataBkd["data"]["data"][0][0];

    const resPred = await fetch(predUrl, { method: 'POST', headers: headers, body: JSON.stringify(paramPred) });
    const dataPred = await resPred.json();
    const predImps = dataPred["data"]["data"][0][0];

    return [bkdImps, predImps]
  };

  async dmaProdPub_data(dma: string,
    product: string,
    publishers: string[],
    start_date: string,
    end_date: string): Promise<number[]> {

    const paramBkd = {
      'DMA': [dma],
      'PRODUCTS': [product],
      'SEGMENTS': [],
      'START_DATE': start_date,
      'END_DATE': end_date
    };

    const paramPred = {
      'DMA': [dma],
      'PRODUCTS': [product],
      'PUBLISHERS': publishers,
      'START_DATE': start_date,
      'END_DATE': end_date
    };

    const headers = {
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    };

    const bkdUrl = 'https://us-central1-premion-audience-engagement.cloudfunctions.net/FA_DMA_Product_Bkd_Dev';
    const predUrl = 'https://us-central1-premion-audience-engagement.cloudfunctions.net/FA_DMA_Product_Publisher_Pred_Dev_2';

    const resBkd = await fetch(bkdUrl, { method: 'POST', headers: headers, body: JSON.stringify(paramBkd) });
    const dataBkd = resBkd ? await resBkd.json() : {};
    const bkdImps = dataBkd ? dataBkd["data"]["data"][0][0] : {};

    const resPred = await fetch(predUrl, { method: 'POST', headers: headers, body: JSON.stringify(paramPred) });
    const dataPred = await resPred.json();
    const predImps = dataPred["data"]["data"][0][0];
    return [bkdImps, predImps];
  };

  async dmaProdPubSeg_data(dma: string,
    product: string,
    publishers: string[],
    segments: string[],
    start_date: string,
    end_date: string): Promise<number[]> {

    const paramBkd = {
      'DMA': [dma],
      'PRODUCTS': [product],
      'SEGMENTS': segments,
      'START_DATE': start_date,
      'END_DATE': end_date
    };

    const paramPred = {
      'DMA': [dma],
      'PRODUCTS': [product],
      'PUBLISHERS': publishers,
      'SEGMENTS': segments,
      'START_DATE': start_date,
      'END_DATE': end_date
    };

    const headers = {
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    };

    const bkdUrl = 'https://us-central1-premion-audience-engagement.cloudfunctions.net/FA_DMA_Product_Bkd_Dev';
    const predUrl = 'https://us-central1-premion-audience-engagement.cloudfunctions.net/FA_DMA_Product_Publisher_Segment_Pred_Dev_2';

    const resBkd = await fetch(bkdUrl, { method: 'POST', headers: headers, body: JSON.stringify(paramBkd) });
    const dataBkd = await resBkd.json();
    const bkdImps = dataBkd["data"]["data"][0][0];

    const resPred = await fetch(predUrl, { method: 'POST', headers: headers, body: JSON.stringify(paramPred) });
    const dataPred = await resPred.json();
    const predImps = dataPred["data"]["data"][0][0];
    return [bkdImps, predImps]
  };

  async daypartData(dma: string[]): Promise<void> {
    //this.daypart_data = [];
    const url = 'https://us-central1-premion-audience-engagement.cloudfunctions.net/FA_DMA_Daypart_Dev';
    const headers = {
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    };
    const payload = {
      "DMA": dma
    };
    const res = await fetch(url, { method: 'POST', headers: headers, body: JSON.stringify(payload) });
    const data = await res.json();
    const daypartDataRes = data["data"]["data"];
    let tempDayPart: any[] = [];
    if (daypartDataRes && daypartDataRes.length > 0) {
      daypartDataRes.forEach((d: any[]) => {
        tempDayPart.push({ name: d[0], value: d[1] });
      });
    }
    this.daypart_data = tempDayPart;

    console.log('Daypart Data', this.daypart_data);
  };

  async ottData(dma: string[]): Promise<void> {
    //this.ott_data = [];
    const url = 'https://us-central1-premion-audience-engagement.cloudfunctions.net/FA_DMA_Ott_Dist_Dev';
    const headers = {
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    };
    const payload = {
      "DMA": dma
    };
    const res = await fetch(url, { method: 'POST', headers: headers, body: JSON.stringify(payload) });
    const data = await res.json();
    const ottData = data["data"]["data"];
    let tempOtt: any[] = [];
    if (ottData && ottData.length > 0) {
      ottData.forEach((d: any[]) => {
        tempOtt.push({ name: d[0], value: d[1], label: d[0] + "%" });
      });
    }
    this.ott_data = tempOtt;

    console.log('Ott Data Zip ', this.ott_data);
  };

  async zipProd_data(
    product: string,
    segments: string,
    start_date: string,
    end_date: string, zips: string): Promise<number[]> {

    const paramBkd = {
      'PRODUCTS': [product],
      'SEGMENTS': [],
      'START_DATE': start_date,
      'END_DATE': end_date,
      'ZIPCODES': zips.split(',')
    };
    const paramPred = {
      'PRODUCTS': [product],
      'START_DATE': start_date,
      'END_DATE': end_date,
      'ZIPCODES': zips.split(',')
    };
    // DENVER 80002,80041,80514,80016
    // ATLANTA 30269,30026,30118,30256,30334,31026
    let zipbkdImpressions = await this.forecasterService.getZippedBookedImpressions(paramBkd);
    console.log("zipped bkd impressions as ---> " + zipbkdImpressions.data);
    const bkdImps = zipbkdImpressions.data ? zipbkdImpressions.data : 0;
    const resPred = await this.forecasterService.getZippedForecasterImpressions(paramPred);
    const predImps = resPred.data;
    return [bkdImps, predImps];
  };

  async zipProdSeg_data(
    product: string,
    segment: string[],
    start_date: string,
    end_date: string, zips: string): Promise<number[]> {

    const paramBkd = {
      'PRODUCTS': [product],
      'SEGMENTS': segment,
      'START_DATE': start_date,
      'END_DATE': end_date,
      'ZIPCODES': zips.split(',')
    };
    const paramPred = {
      'PRODUCTS': [product],
      'SEGMENTS': segment,
      'START_DATE': start_date,
      'END_DATE': end_date,
      'ZIPCODES': zips.split(',')
    };
    // 80002,80041,80514,80016
    let zipbkdImpressions = await this.forecasterService.getZippedBookedImpressions(paramBkd);
    console.log("zipped bkd impressions as ---> " + zipbkdImpressions.data[0]);
    const bkdImps = zipbkdImpressions.data ? zipbkdImpressions.data : 0;
    let resPred = await this.forecasterService.getZippedSegmentForecasterImpressions(paramPred);
    const predImps = resPred.data;
    return [bkdImps, predImps];
  };

  async zipProdPub_data(
    product: string,
    publishers: string[],
    start_date: string,
    end_date: string, zips: string): Promise<number[]> {

    const paramBkd = {
      'PRODUCTS': [product],
      'START_DATE': start_date,
      'END_DATE': end_date,
      'ZIPCODES': zips.split(',')
    };
    const paramPred = {
      'PRODUCTS': [product],
      'PUBLISHERS': publishers,
      'START_DATE': start_date,
      'END_DATE': end_date,
      'ZIPCODES': zips.split(',')
    };
    // 80002,80041,80514,80016
    let zipbkdImpressions = await this.forecasterService.getZippedBookedImpressions(paramBkd);
    console.log("zipped bkd impressions as ---> " + zipbkdImpressions.data[0]);
    const bkdImps = zipbkdImpressions.data ? zipbkdImpressions.data : 0;
    let resPred = await this.forecasterService.getZippedPublisherForecasterImpressions(paramPred);
    const predImps = resPred.data;
    return [bkdImps, predImps];
  };

  async zipProdPubSeg_data(
    product: string,
    publishers: string[],
    segments: string[],
    start_date: string,
    end_date: string,
    zips: string): Promise<number[]> {

    const paramPred = {
      'PRODUCTS': [product],
      'PUBLISHERS': publishers,
      'SEGMENTS': segments,
      'START_DATE': start_date,
      'END_DATE': end_date,
      'ZIPCODES': zips.split(',')
    };
    const paramBkd = {
      'PRODUCTS': [product],
      'SEGMENTS': segments,
      'START_DATE': start_date,
      'END_DATE': end_date,
      'ZIPCODES': zips.split(',')
    };
    // 80002,80041,80514,80016
    let zipbkdImpressions = await this.forecasterService.getZippedBookedImpressions(paramBkd);
    if (zipbkdImpressions) {
      this.hideloader();
    }
    console.log("zipped bkd impressions as ---> " + zipbkdImpressions.data[0]);
    const bkdImps = zipbkdImpressions.data ? zipbkdImpressions.data : 0;
    let resPred = await this.forecasterService.getZippedPub_SegForecasterImpressions(paramPred);
    const predImps = resPred.data;
    return [bkdImps, predImps];
  };

  async daypartZipData(zip: string[]): Promise<void> {
    //this.daypart_data = [];
    const url = 'https://us-central1-premion-audience-engagement.cloudfunctions.net/FA_ZIP_Daypart_Dev';
    const headers = {
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    };
    const payload = {
      "ZIPCODES": zip
    };
    const res = await fetch(url, { method: 'POST', headers: headers, body: JSON.stringify(payload) });
    const data = await res.json();
    const daypartDataRes = data["data"]["data"];
    let tempDayPart: any[] = [];
    if (daypartDataRes && daypartDataRes.length > 0) {
      daypartDataRes.forEach((d: any[]) => {
        tempDayPart.push({ name: d[0], value: d[1] });
      });
    }
    this.daypart_data = tempDayPart;
    console.log('Daypart Data Zip', this.daypart_data);
  };

  async ottZipData(zip: string[]): Promise<void> {
    // this.ott_data = [];
    const url = 'https://us-central1-premion-audience-engagement.cloudfunctions.net/FA_ZIP_Ott_Dist_Dev';
    const headers = {
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    };
    const payload = {
      "ZIPCODES": zip
    };
    const res = await fetch(url, { method: 'POST', headers: headers, body: JSON.stringify(payload) });
    const data = await res.json();
    const ottData = data["data"]["data"];
    let tempOtt: any[] = [];
    if (ottData && ottData.length > 0) {
      ottData.forEach((d: any[]) => {
        tempOtt.push({ name: d[0], value: d[1], label: d[0] + "%" });
      });
    }
    this.ott_data = tempOtt;
    console.log('OTT Data Zip ', this.ott_data);
  };

  calculateDays(startDate: any, endDate: any): number {
    let diffDays: any = Math.floor((endDate - startDate) / (1000 * 60 * 60 * 24));
    return diffDays + 1;
  }

  differenceInMonths(startDate: any, endDate: any) {
    const monthDiff = endDate.getMonth() - startDate.getMonth();
    const yearDiff = endDate.getYear() - startDate.getYear();
    return (monthDiff > 0 ? monthDiff : 1) + yearDiff * 12;
  }

  weeksBetween(startDate: any, endDate: any) {
    return Math.round((endDate - startDate) / (7 * 24 * 60 * 60 * 1000));
  }

  calculateDifference(): void {
    let diffDays: any = this.calculateDays(new Date(this.start_date), new Date(this.end_date));
    // let diffMonth: any = this.differenceInMonths(new Date(this.start_date), new Date(this.end_date));
    // let diffweeks: any = this.weeksBetween(new Date(this.start_date), new Date(this.end_date));
    // this.monthly_imps = Math.round(this.available_imps / diffMonth);
    // this.weekly_imps = Math.round(this.available_imps / diffweeks);
    // this.daily_imps = Math.round(this.available_imps / diffDays);
    // console.log(diffDays, diffMonth, diffweeks);

    this.daily_imps = Math.round(this.available_imps / diffDays);
    this.monthly_imps = Math.round(this.daily_imps * 30);
    this.weekly_imps = Math.round(this.daily_imps * 7);

    if (new Date(this.end_date).getMonth() == new Date(this.start_date).getMonth()) {
      let totalDaysInMonth = this.getTotalDaysInMonth(new Date(this.start_date));
      if (diffDays == totalDaysInMonth) {
        this.monthly_imps = this.available_imps;
      } else {
        this.monthly_imps = Math.round(this.daily_imps * totalDaysInMonth);
      }
    }
  }

  getTotalDaysInMonth(date: Date): number {
    // Get the month and year from the given date
    const month = date.getMonth() + 1; // Adding 1 because getMonth returns zero-based index
    const year = date.getFullYear();

    // Create a new Date object for the next month's first day and subtract one day to get the last day of the current month
    const lastDay = new Date(year, month, 0);

    // Return the day part of the last day, which represents the number of days in the month
    return lastDay.getDate();
  }

  hideloader(): void {
    if (document.getElementById('loading')) {
      let obj: any = document.getElementById('loading');
      obj.style.display = 'none';
    }
  }

  resetMetricData(): void {
    this.available_imps = 0;
    this.booked_imps = 0;
    this.forecasted_imps = 0;
    this.monthly_imps = 0;
    this.weekly_imps = 0;
    this.daily_imps = 0;
    this.household_nums = 0
    this.total_population = 0;

    this.rowData[0]['capacity'] = String(formatNumber(this.forecasted_imps, 'en-US', '1.0'));
    this.rowData[0]['reserved'] = String(formatNumber(this.booked_imps, 'en-US', '1.0'));
    this.rowData[0]['available'] = String(formatNumber(this.available_imps, 'en-US', '1.0'));
    this.rowData[0]['status'] = "Processing";
  }

}
