import { Component, OnInit } from '@angular/core';
import { ForecastTableComponent } from '../forecast-table/forecast-table.component';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-custom-toolbar',
  templateUrl: './app-toolbar.component.html',
  styleUrls: ['./app-toolbar.component.css']
})
export class AppToolbarComponent implements OnInit {
  //exportComponent = new ForecastTableComponent(this.route);
  constructor(private route: ActivatedRoute) { }

  ngOnInit(): void {
  }
  
  // exportTOExcel(): void{
  //   this.exportComponent.exportTOExcel();
  // }
}
