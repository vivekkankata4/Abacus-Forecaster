import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-custom-toolbar',
  templateUrl: './custom-toolbar.component.html',
  styleUrls: ['./custom-toolbar.component.css']
})
export class CustomToolbarComponent implements OnInit {

  @ViewChild('paginator') paginator: MatPaginator;
  @Output() searchText = new EventEmitter<string>();
  @Output() paginatorData = new EventEmitter<string>();
  @Input() totalRecords: number;
  currentPage: number = 0;
  pageSize: number = 5;

  constructor(private route: ActivatedRoute) { }

  ngOnInit(): void { }

  emitSearchText(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.searchText.emit(filterValue);
  }

  onPageChange(event: any) {
    let pagination = { currentPage: event.pageIndex, pageSize: event.pageSize };
    this.paginatorData.emit(JSON.stringify(pagination));
  }

  onPageSizeChange(event: any) {
    let pagination = { currentPage: event.pageIndex, pageSize: event.pageSize };
    this.paginatorData.emit(JSON.stringify(pagination));
  }
}
