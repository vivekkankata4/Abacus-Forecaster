import { animate, state, style, transition, trigger } from '@angular/animations';
import { formatNumber } from '@angular/common';
import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { saveAs } from 'file-saver';
import html2canvas from 'html2canvas';
import * as pdfMake from 'pdfmake/build/pdfmake';
import * as pdfFonts from 'pdfmake/build/vfs_fonts';
import { take } from 'rxjs';
import { ForecastHelper } from 'src/app/common/helper/forecastHelper';
import { SharedDataHelper } from 'src/app/common/helper/sharedDataHelper';
import { ForecasterService } from 'src/app/common/service/forecaster.service';
(pdfMake as any).vfs = pdfFonts.pdfMake.vfs;


@Component({
  selector: 'app-forecast-table',
  templateUrl: './forecast-table.component.html',
  styleUrls: ['./forecast-table.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})

export class ForecastTableComponent implements OnInit {
  @ViewChild('paginator') paginator: MatPaginator;
  isLoading = false;
  pageSizes: number[] = [5, 10];
  totalRecords: number;
  expandedElement: any | null;
  private errorMessage?: string;
  public isZip: boolean = false;
  public isSummaryScreen = true;
  public userForecastHistory: any[] = [];
  public zipCodeList: { name: string, isSelected: boolean, zipCodes: string }[] = [];
  public selectedDma: string[] = [];
  daypart_data: any[];
  ott_data: any[];
  public COLUMNS_SCHEMA: {
    key: string;
    type: string;
    label: string;
  }[] = [
      { key: "forecast_date", type: "text", label: "Forecast Date" },
      { key: "forecaster_name", type: "text", label: "Forecast Name" },
      { key: "product", type: "text", label: "Product" },
      { key: "dma", type: "text", label: "Geo" },
      { key: "segment", type: "text", label: "Segments" },
      { key: "stDate", type: "text", label: "Start Date" },
      { key: "endDate", type: "text", label: "End Date" },
      { key: "sales_planner", type: "text", label: "Sales Planner" },
      { key: "status", type: "text", label: "Status" },
      { key: "selectedDma", type: "text", label: "selectedDma" },
      { key: "rowIdx", type: "text", label: "rowIdx" },
      { key: "forecastHis", type: "text", label: "forecastHis" },
      { key: "geofilters", type: "text", label: "geofilters" },
      { key: "isZipVersion", type: "boolean", label: "isZipVersion" },
      { key: "forecastId", type: "text", label: "forecastId" },
      { key: "actions", type: "boolean", label: "Actions" }
    ];

  public rowData: any[];
  dataForecastList = new MatTableDataSource<any>();
  displayedForecastColumnsList: string[] = ['forecast_date', 'forecaster_name', 'product',
    'dma', 'segment', 'stDate', 'endDate', 'sales_planner', 'status', 'actions'];
  public agency_name: string;
  public advertiser_name: string;
  public product: string;
  public geo_list: string[] = [];
  public zip_list: any[] = [];
  public segment_names: string[] = [];
  public publisher_names: string[] = [];
  public start_date: string = '';
  public end_date: string = '';
  public booked_imps: number = 0;
  public forecasted_imps: number = 0;
  public available_imps: number = 0;
  public monthly_imps: number = 0;
  public weekly_imps: number = 0;
  public daily_imps: number = 0;
  public household_nums: number = 0;
  public total_population: number = 0;
  public dma: string;
  saveForecastPayloadStr: string;
  saveForecastPayload: any;
  userName!: string;
  isFromGenerateScreen: boolean = false;
  currentPage: number = 1;
  pageSize: number = 5;
  forecaster_name: any;
  forecastDate: any;
  firstRowHistory: any;

  constructor(private forecasterService: ForecasterService,
    private forecasthelper: ForecastHelper, private sharedDataHelper: SharedDataHelper) { }

  ngOnInit(): void {
    this.userName = sessionStorage.getItem('userLogin')!;
    this.firstRowHistory = null;
    this.rowData = [];

    this.sharedDataHelper.getForecastPayload.pipe(take(1)).
      subscribe(payload => this.saveForecastPayloadStr = payload);

    if (this.saveForecastPayloadStr && this.saveForecastPayloadStr != '') {
      this.saveForecastPayload = Object.assign({}, JSON.parse(this.saveForecastPayloadStr));
      this.sharedDataHelper.setForecastPayload("");

      this.isFromGenerateScreen = true;
      let data = this.saveForecastPayload;
      this.forecaster_name = data.FORECASTER_NAME;
      this.agency_name = data.AGENCY;
      this.advertiser_name = data.ADVERTISER;
      this.product = data.PRODUCTS[0];
      this.geo_list = data.DMA;
      this.zip_list = data.ZIPS;
      this.segment_names = data.SEGMENTS;
      this.publisher_names = data.PUBLISHERS;
      this.start_date = data.START_DATE;
      this.end_date = data.END_DATE;
      this.saveUserForecast(this.saveForecastPayload, (data.ZIPCODE_LIST && data.ZIPCODE_LIST.length > 0))
    }
    this.fetchPaginatedData();
  }

  isTableExpanded = false;
  expandedRowIndex: number;
  toggleTableRows(event: MouseEvent, rowElement: any, index: number) {
    console.log("toggle expanded")
    let isZipRow = this.rowData[index]['isZipVersion'];
    if (isZipRow) {
      this.dma = this.rowData[index]['selectedDma'].zipCodes.toString();
      this.isZip = true;
      this.onZipFetchData(this.rowData[index]['selectedDma'], index);
    } else {
      this.dma = this.rowData[index]['selectedDma'];
      this.isZip = false;
      this.onDMAFetchData(this.dma, index);
    }
    this.expandedRowIndex = (this.expandedRowIndex == index) ? -1 : index;
    this.expandedElement = rowElement ? rowElement : null;
  }

  populateFilters(idx: number) {
    let filterData = this.rowData[idx]['geofilters'];
    this.agency_name = filterData.AGENCY;
    this.advertiser_name = filterData.ADVERTISER;
    let zipNames: string[] = [];
    if (!filterData.DMA) {
      this.isZip = true;
      filterData.ZIPCODE_LIST.forEach((element: any) => {
        zipNames.push(element.name);
      });
    }
    this.geo_list = filterData.DMA ? filterData.DMA : zipNames.toString();
    this.segment_names = filterData.SEGMENTS!.length > 0 ? filterData.SEGMENTS : [];
    this.publisher_names = filterData.PUBLISHERS.length > 0 ? filterData.PUBLISHERS : [];
  }

  populateFiltersAndCharts(index: number, isZipRow: boolean, rowElement: any) {
    this.populateChartData(index, isZipRow);
    this.populateFilters(index);
  }

  populateChartData(idx: number, isZippedRow: boolean) {
    let geotargetData = this.rowData[idx]['forecastHis'];
    let selectedGeoTarget: any;
    if (isZippedRow) {
      selectedGeoTarget = geotargetData.filter((x: any) => x.name === this.rowData[idx]['selectedDma'].name);
    }
    else {
      selectedGeoTarget = geotargetData.filter((x: any) => x.dma.toLowerCase() === this.rowData[idx]['selectedDma'].toLowerCase());
    }

    let tempDayPart: any[] = [];
    if (selectedGeoTarget[0].values.daypart_dist && selectedGeoTarget[0].values.daypart_dist.length > 0) {
      selectedGeoTarget[0].values.daypart_dist.forEach((d: any[]) => {
        tempDayPart.push({ name: d[0], value: d[1] });
      });
    }
    this.daypart_data = tempDayPart;

    let tempOtt: any[] = [];
    if (selectedGeoTarget[0].values.ott_dist && selectedGeoTarget[0].values.ott_dist.length > 0) {
      selectedGeoTarget[0].values.ott_dist.forEach((d: any[]) => {
        tempOtt.push({ name: d[0], value: d[1], label: d[0] + "%" });
      });
    }
    this.ott_data = tempOtt;
  }

  async onZipFetchData(dma: any, idx: number) {
    this.rowData[idx]['selectedDma'] = dma;
    this.isZip = true;
    this.dma = dma.zipCodes.toString();
    let geotargetData = this.rowData[idx]['forecastHis'];
    let selectedGeoTarget = geotargetData.filter((x: any) => x.name === this.rowData[idx]['selectedDma'].name);
    //let totals = await this.getHouseholds(dma, true);
    this.household_nums = Math.round(selectedGeoTarget[0].values.ttl_households);
    this.total_population = Math.round(selectedGeoTarget[0].values.ott_household);
    this.forecasted_imps = Math.round(selectedGeoTarget[0].values.capacity);
    this.available_imps = Math.round(selectedGeoTarget[0].values.avail);
    this.booked_imps = Math.round(selectedGeoTarget[0].values.reserved);
    this.daily_imps = Math.round(selectedGeoTarget[0].values.daily);
    this.weekly_imps = Math.round(selectedGeoTarget[0].values.weekly);
    this.monthly_imps = Math.round(selectedGeoTarget[0].values.monthly);
    this.populateFiltersAndCharts(idx, true, this.rowData[idx]);
    this.rowData[idx]['status'] = "Completed";
  };

  async onDMAFetchData(dma: string, idx: number) {
    console.log("onDMAFetchData");
    console.log(dma, idx);
    this.rowData[idx]['selectedDma'] = dma;
    this.dma = dma;
    this.isZip = false;
    let geotargetData = this.rowData[idx]['forecastHis'];
    let selectedGeoTarget = geotargetData.filter((x: any) => x.dma.toLowerCase() === dma.toLowerCase());
    //let totals = await this.getHouseholds(dma, true);
    this.household_nums = Math.round(selectedGeoTarget[0].values.ttl_households);
    this.total_population = Math.round(selectedGeoTarget[0].values.ott_household);
    this.forecasted_imps = Math.round(selectedGeoTarget[0].values.capacity);
    this.available_imps = Math.round(selectedGeoTarget[0].values.avail);
    this.booked_imps = Math.round(selectedGeoTarget[0].values.reserved);
    this.daily_imps = Math.round(selectedGeoTarget[0].values.daily);
    this.weekly_imps = Math.round(selectedGeoTarget[0].values.weekly);
    this.monthly_imps = Math.round(selectedGeoTarget[0].values.monthly);
    this.populateFiltersAndCharts(idx, false, this.rowData[idx]);
    this.rowData[idx]['status'] = "Completed";
  };

  calculateDays(startDate: any, endDate: any): number {
    let diffDays: any = Math.floor((endDate - startDate) / (1000 * 60 * 60 * 24));
    return diffDays + 1;
  }

  differenceInMonths(startDate: any, endDate: any) {
    const monthDiff = endDate.getMonth() - startDate.getMonth();
    const yearDiff = endDate.getYear() - startDate.getYear();
    return (monthDiff > 0 ? monthDiff : 1) + yearDiff * 12;
  }

  weeksBetween(startDate: any, endDate: any) {
    return Math.round((endDate - startDate) / (7 * 24 * 60 * 60 * 1000));
  }

  calculateDifference(): void {
    let diffDays: any = this.calculateDays(new Date(this.start_date), new Date(this.end_date));
    this.daily_imps = Math.round(this.available_imps / diffDays);
    this.monthly_imps = Math.round(this.daily_imps * 30);
    this.weekly_imps = Math.round(this.daily_imps * 7);

    if (new Date(this.end_date).getMonth() == new Date(this.start_date).getMonth()) {
      let totalDaysInMonth = this.getTotalDaysInMonth(new Date(this.start_date));
      if (diffDays == totalDaysInMonth) {
        this.monthly_imps = this.available_imps;
      } else {
        this.monthly_imps = Math.round(this.daily_imps * totalDaysInMonth);
      }
    }
  }

  getTotalDaysInMonth(date: Date): number {
    // Get the month and year from the given date
    const month = date.getMonth() + 1; // Adding 1 because getMonth returns zero-based index
    const year = date.getFullYear();

    // Create a new Date object for the next month's first day and subtract one day to get the last day of the current month
    const lastDay = new Date(year, month, 0);

    // Return the day part of the last day, which represents the number of days in the month
    return lastDay.getDate();
  }

  resetMetricData(idx: number): void {
    this.available_imps = 0;
    this.booked_imps = 0;
    this.forecasted_imps = 0;
    this.monthly_imps = 0;
    this.weekly_imps = 0;
    this.daily_imps = 0;
    this.household_nums = 0
    this.total_population = 0;

    this.rowData[idx]['capacity'] = String(formatNumber(this.forecasted_imps, 'en-US', '1.0'));
    this.rowData[idx]['reserved'] = String(formatNumber(this.booked_imps, 'en-US', '1.0'));
    this.rowData[idx]['available'] = String(formatNumber(this.available_imps, 'en-US', '1.0'));
    this.rowData[idx]['status'] = "Completed";
  }

  applyFilter(searchText: string) {
    this.dataForecastList.filter = searchText.trim().toLowerCase();
  }

  updateZip(zipcode: string[]): string {
    return zipcode.toString();
  }

  populateFirstRecord() {
    this.firstRowHistory = {
      filters: {
        FORECAST_NAME: this.saveForecastPayload.FORECAST_NAME,
        AGENCY: this.saveForecastPayload.AGENCY,
        ADVERTISER: this.saveForecastPayload.ADVERTISER,
        DMA: (this.saveForecastPayload.DMA && this.saveForecastPayload.DMA.length > 0 ? this.saveForecastPayload.DMA : this.saveForecastPayload.ZIPCODE_LIST),
        SEGMENTS: this.saveForecastPayload.SEGMENTS ? this.saveForecastPayload.SEGMENTS! : [],
        PUBLISHERS: this.saveForecastPayload.PUBLISHER! ? this.saveForecastPayload.PUBLISHER! : [],
        PRODUCTS: this.saveForecastPayload.PRODUCTS,
        START_DATE: this.saveForecastPayload.START_DATE,
        END_DATE: this.saveForecastPayload.END_DATE,
      },
      geoTargets: null,
      forecast_date: this.forecasthelper.getTodayDate()
    }
    this.userForecastHistory.push(this.firstRowHistory);
    this.populateTableData(0, "Processing");
    this.dataForecastList.data = this.rowData;
  }

  populateTableData(idx: number, processingStatus: string) {
    let aRow = this.userForecastHistory[idx];
    if (aRow) {
      let geoTargets = null;
      let geoFilters = null;
      if (aRow['filters']) {
        geoFilters = aRow['filters'];
        this.start_date = aRow.filters.START_DATE;
        this.end_date = aRow.filters.END_DATE;
        if (aRow.filters.ZIPCODE_LIST && aRow.filters.ZIPCODE_LIST.length > 0) {
          this.geo_list = aRow.filters.ZIPCODE_LIST;
          this.selectedDma[idx] = aRow.filters.ZIPCODE_LIST[0];
          let tempDma = aRow.filters.ZIPCODE_LIST[0].zipCodes.toString();
          this.dma = tempDma;
          this.isZip = true;
        } else {
          this.geo_list = aRow.filters.DMA;
          this.selectedDma[idx] = aRow.filters.DMA[0];
          this.dma = aRow.filters.DMA[0];
          this.isZip = false;
        }
        this.forecastDate = aRow.forecast_date ? aRow.forecast_date : aRow.FORECAST_DATE;
        this.forecaster_name = aRow.filters.FORECAST_NAME,
          this.product = aRow.filters.PRODUCTS;
        this.agency_name = aRow.filters.AGENCY;
        this.advertiser_name = aRow.filters.ADVERTISER;
        this.segment_names = aRow.filters.SEGMENTS!.length > 0 ? aRow.filters.SEGMENTS : [];
        this.publisher_names = aRow.filters.PUBLISHERS.length > 0 ? aRow.filters.PUBLISHERS : [];
      }

      if (aRow['geo_targets']) {
        geoTargets = aRow['geo_targets'];
        this.household_nums = Math.round(aRow['geo_targets'][0].values.ttl_households);
        this.total_population = Math.round(aRow['geo_targets'][0].values.ott_household);
        this.forecasted_imps = Math.round(aRow['geo_targets'][0].values.capacity);
        this.available_imps = Math.round(aRow['geo_targets'][0].values.avail);
        this.booked_imps = Math.round(aRow['geo_targets'][0].values.reserved);
        this.daily_imps = Math.round(aRow['geo_targets'][0].values.daily);
        this.weekly_imps = Math.round(aRow['geo_targets'][0].values.weekly);
        this.monthly_imps = Math.round(aRow['geo_targets'][0].values.monthly);
      }

      let userForecastRow = {
        Id: aRow.forecastId,
        forecaster_name: this.forecaster_name && this.forecaster_name !== '' ? this.forecaster_name : 'July_Forecast',
        forecast_date: this.forecastDate,
        product: this.product,
        dma: this.geo_list,
        segment: this.segment_names!.length > 0 ? this.segment_names : "No Segments Selected",
        advertiser: this.advertiser_name,
        stDate: this.start_date,
        endDate: this.end_date,
        monthly: this.monthly_imps,
        weekly: this.weekly_imps,
        daily: this.daily_imps,
        sales_planner: this.userName,
        status: processingStatus,
        isExpanded: false,
        selectedDma: this.selectedDma[idx],
        forecastHis: geoTargets,
        rowIdx: idx,
        geofilters: geoFilters,
        isZipVersion: geoFilters.ZIPCODE_LIST!
      }
      this.rowData[idx] = userForecastRow;
    }
  }

  async saveUserForecast(filters: any, isZipped: boolean) {
    await this.forecasterService.saveUserForecast(filters, isZipped).then(
      response => {
        let responseStr = JSON.stringify(response['data']).replace("FILTERS", "filters").replace("GEO_TARGETS", "geo_targets");
        this.userForecastHistory[0] = JSON.parse(responseStr);
        this.populateTableData(0, "Completed");
        this.dataForecastList.data = this.rowData;
      }
    ).catch(error => {
      console.log(error);
    })

  };

  @Input() currentPageNo: number;
  @Input() pageSizeNo: number;

  onPagination(event: any) {
    let pagination = JSON.parse(event);
    this.currentPageNo = pagination.currentPage;
    this.pageSizeNo = pagination.pageSize;
    this.fetchPaginatedData();
  }

  fetchPaginatedData() {
    this.isZip = false;
    this.isLoading = true;
    let recordsPerPage;
    if (this.isFromGenerateScreen) {
      if (!this.firstRowHistory || this.rowData[0]['status'] == "Processing") {
        this.rowData = [];
        this.userForecastHistory = [];
        recordsPerPage = this.pageSizeNo ? this.pageSizeNo - 1 : 4;
        this.populateFirstRecord();
      } else {
        this.rowData = [];
        this.userForecastHistory = [];
        recordsPerPage = this.pageSizeNo ? this.pageSizeNo : 5;
      }
    } else {
      this.rowData = [];
      this.userForecastHistory = [];
      recordsPerPage = this.pageSizeNo ? this.pageSizeNo : 5;
    }

    this.forecasterService.getUserForecastHistory({
      "USER_NAME": this.userName,
      "CURRENT_PAGE": this.currentPageNo ? this.currentPageNo + 1 : 1,
      "RECORDS_PER_PAGE": recordsPerPage
    }).pipe(take(1)).
      subscribe(response => {
      this.isLoading = false;
      this.rowData.push(...response.data);
      this.totalRecords = (this.isFromGenerateScreen && this.rowData[0]['status'] == "Processing") ? response.totalRecords + 1 : response.totalRecords;
      this.currentPageNo = response.currentPage;
      if (this.rowData && this.rowData.length > 0) {
        let userHistoryArray: any[] = response.data;
        userHistoryArray.sort((a, b) => { return (b.forecastId - a.forecastId) });
        this.userForecastHistory.push(...userHistoryArray);
        let idx = (this.isFromGenerateScreen && this.rowData[0]['status'] == "Processing") ? 1 : 0;
        this.userForecastHistory.forEach(aRow => {
          this.populateTableData(idx, "Completed");
          idx++;
        });
        this.dataForecastList = new MatTableDataSource(this.rowData);
      }

    });
  }

  isGeneratePDF: boolean = false;
  generatePDF(index: number) {
    if (!this.rowData[index]['isZipVersion']) {
      let olderDMA = this.rowData[index]['selectedDma'];
      let availableDMA = this.rowData[index]['dma']
      for (let i = 0; i < availableDMA.length; i++) {
        this.dma = availableDMA[i];
        this.isZip = false;
        this.onDMAFetchData(this.dma, index);
        this.setDMADataforPDF(index);
      }
      this.onDMAFetchData(olderDMA, index);

    } else {
      this.setDMADataforPDF(index);
    }
  }


  setDMADataforPDF(index: number) {
    let columnData = this.setPDFSummary(index);
    const divElement: any = document.getElementById('grid-dashboard-container');
    html2canvas(divElement, {
      useCORS: true,
      backgroundColor: null,
      imageTimeout: 0,
      removeContainer: true,
      scale: (window.devicePixelRatio * 2)
    }).then((canvas) => {
      //canvas.style.filter = 'brightness(1.2)';
      const imageData1 = canvas.toDataURL('image/png');
      const documentDefinition: any = {
        content: [
          {
            text: 'Premion Forecast Report',
            style: 'header',
            alignment: 'center',
            decoration: 'underline',
            margin: [0, 40, 0, 0], // Adjust the margins as needed
          },
          columnData,
          {
            columns: [{
              image: imageData1,
              width: 500,
              margin: [0, 20, 0, 0]
            }]
          }


        ],
        styles: {
          header: {
            fontSize: 16,
            bold: true,
            alignment: 'center',
          },
          subHeader: {
            fontSize: 12,
            bold: true,
            alignment: 'left',
          },
          text: {
            fontSize: 10,
            bold: true,
            alignment: 'left',
          }
        }
      };
      pdfMake.createPdf(documentDefinition).download();
    });
  }

  setPDFSummary(index: number): any {
    let columnDataVal: any[] = [];
    let forecastrow = this.rowData[index];

    let forecastDt = {
      alignment: 'left',
      columns: this.setPDFCoulmnData("Forecast Date:", forecastrow['forecast_date'])
    };
    columnDataVal.push(forecastDt);

    let forecastName = {
      alignment: 'left',
      columns: this.setPDFCoulmnData("Forecast Name:", forecastrow['forecaster_name'])
    };
    columnDataVal.push(forecastName);

    let product = {
      alignment: 'left',
      columns: this.setPDFCoulmnData("Product:", forecastrow['product'].toString())
    };
    columnDataVal.push(product);

    if (forecastrow['isZipVersion'] && forecastrow['isZipVersion'].length > 0) {
      let geo = {
        alignment: 'left',
        columns: this.setPDFCoulmnData("Geo:", forecastrow['selectedDma'].zipCodes.toString())
      };
      columnDataVal.push(geo);
    } else {
      let geo = {
        alignment: 'left',
        columns: this.setPDFCoulmnData("Geo:", forecastrow['selectedDma'].toString())
      };
      columnDataVal.push(geo);
    }


    if (forecastrow['agency'] && forecastrow['agency'] != '') {
      let agency = {
        alignment: 'left',
        columns: this.setPDFCoulmnData("Agency:", forecastrow['agency'].toString())
      };
      columnDataVal.push(agency);
    }

    if (forecastrow['advertiser'] && forecastrow['advertiser'] != '') {
      let advertiser = {
        alignment: 'left',
        columns: this.setPDFCoulmnData("Advertiser:", forecastrow['advertiser'].toString())
      };
      columnDataVal.push(advertiser);
    }

    if (forecastrow['segment'] && forecastrow['segment'] != '') {
      let segment = {
        alignment: 'left',
        columns: this.setPDFCoulmnData("Segments:", forecastrow['segment'].toString())
      };
      columnDataVal.push(segment);
    }

    if (forecastrow['publishers'] && forecastrow['publishers'] != '') {
      let publishers = {
        alignment: 'left',
        columns: this.setPDFCoulmnData("Publishers:", forecastrow['publishers'].toString())
      };
      columnDataVal.push(publishers);
    }

    return columnDataVal;
  }

  setPDFCoulmnData(header: string, value: string): any {
    let columnData = [
      {
        text: header,
        width: 150,
        style: 'subHeader',
        margin: [0, 15, 0, 0]
      },
      {
        text: value!.replace(/(.{60})/g, '$1\n'),
        margin: [0, 20, 0, 0],
        width: 'auto',
        style: 'text',
      }
    ];

    return columnData;
  }

  adjustBrightness(imgData: string, brightness: number): Promise<string> {
    return new Promise<string>((resolve) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx: any = canvas.getContext('2d');
        canvas.width = img.width;
        canvas.height = img.height;

        // Apply brightness adjustment
        ctx.filter = `contrast(${brightness})`;
        ctx.drawImage(img, 0, 0);

        // Get the adjusted image data
        const adjustedImgData = canvas.toDataURL();
        resolve(adjustedImgData);
      };
      img.src = imgData;
    });
  }

  removeForecastHistory(foreCastId: number) {
    console.log('I am removing forecast  ' + foreCastId);
  }

  generateExcel(idx: number) {
    /**
     * This code was tried until Backed API is fixed. This will generate excel for current API
     * Also, Forecast Date is added before sending the payload - Needs to changed to dynamic
     * Please remove this part once API is fixed
     * ---- Start ---- */
    let str = JSON.stringify(this.userForecastHistory[idx]);
    str = str.replace("filters", "FILTERS").replace("geo_targets", "GEO_TARGETS");
    this.userForecastHistory[idx] = JSON.parse(str);
    this.userForecastHistory[idx].FORECAST_DATE = this.forecasthelper.getTodayDate();
    /* ---- End ----*/

    let request = {
      "EXPORT_DATA": {
        "data": this.userForecastHistory[idx]
      }
    }
    this.forecasterService.exportExcel(request).pipe(take(1)).
      subscribe((response: ArrayBuffer) => {
      const blob = new Blob([response], { type: 'application/octet-stream' });
      saveAs(blob, "data.xlsx");
    })
  }
}
function observableOf(arg0: null) {
  throw new Error('Function not implemented.');
}
