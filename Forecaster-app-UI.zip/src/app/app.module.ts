import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ErrorHandler, NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { GoogleMapsModule } from '@angular/google-maps';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatCommonModule, MatNativeDateModule } from "@angular/material/core";
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from "@angular/material/icon";
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule, MAT_SELECT_CONFIG } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatTableModule } from '@angular/material/table';
import { MatTabsModule } from "@angular/material/tabs";
import { MatTooltipModule } from '@angular/material/tooltip';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgbDatepickerModule, NgbModalModule, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { ToastrModule } from 'ngx-toastr';
import { ForecastHelper } from 'src/app/common/helper/forecastHelper';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SharedDataHelper } from './common/helper/sharedDataHelper';
import { CacheInterceptor } from './common/interceptor/cache.interceptor';
import { FilterPipe } from './common/pipes/filter.pipe';
import { ListFilterPipe } from './common/pipes/list-filter.pipe';
import { LandingPageComponent } from './main/landing-page/landing-page.component';
import { WelcomePageComponent } from './main/welcome-page/welcome-page.component';
import { AlertDialogComponent } from './web/alert-dialog/alert-dialog.component';
import { CustomToolbarComponent } from './web/custom-toolbar/custom-toolbar.component';
import { CampaignDateComponent } from './web/campaign-date/campaign-date.component';
import { ChangePasswordComponent } from './web/change-password/change-password.component';
import { DaypartChartComponent } from './web/daypart-chart/daypart-chart.component';
import { FilterListComponent } from './web/filter-list/filter-list.component';
import { ForecastTableComponent } from './web/forecast-table/forecast-table.component';
import { GeoTabComponent } from './web/geo-tab/geo-tab.component';
import { GridDashboardComponent } from './web/grid-dashboard/grid-dashboard.component';
import { HeaderComponent } from './web/header/header.component';
import { InventoryTabComponent } from './web/inventory-tab/inventory-tab.component';
import { LayoutComponent } from './web/layout/layout.component';
import { LoginComponent } from './web/login/login.component';
import { MetricCardGridComponent } from './web/metric-card-grid/metric-card-grid.component';
import { NavMapComponent } from './web/nav-map/nav-map.component';
import { OttChartComponent } from './web/ott-chart/ott-chart.component';
import { ProductTabComponent } from './web/product-tab/product-tab.component';
import { TabBodyComponent } from './web/tab-body/tab-body.component';
import { VerticalTabComponent } from './web/vertical-tab/vertical-tab.component';
import { ApplicationErrorHandler } from './error.handler';
import {MatSnackBarModule} from '@angular/material/snack-bar';

@NgModule({
  declarations: [
    AppComponent,
    LandingPageComponent,
    FilterPipe,
    ListFilterPipe,
    HeaderComponent,
    CampaignDateComponent,
    TabBodyComponent,
    ProductTabComponent,
    GeoTabComponent,
    VerticalTabComponent,
    InventoryTabComponent,
    WelcomePageComponent,
    ForecastTableComponent,
    CustomToolbarComponent,
    DaypartChartComponent,
    FilterListComponent,
    GridDashboardComponent,
    MetricCardGridComponent,
    NavMapComponent,
    OttChartComponent,
    AlertDialogComponent,
    LoginComponent,
    LayoutComponent,
    ChangePasswordComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    MatTabsModule,
    MatIconModule,
    MatCommonModule,
    NgbModule,
    MatSlideToggleModule,
    MatDatepickerModule,
    MatCardModule,
    MatNativeDateModule,
    NgxChartsModule,
    MatTableModule,
    MatListModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatAutocompleteModule,
    MatTooltipModule,
    MatCheckboxModule,
    ToastrModule.forRoot(),
    GoogleMapsModule,
    MatRadioModule,
    MatDialogModule,
    NgbDatepickerModule,
    NgbModalModule,
    MatProgressSpinnerModule,
    MatPaginatorModule,
    MatSnackBarModule
  ],
  providers: [ForecastHelper, SharedDataHelper, {
    provide: HTTP_INTERCEPTORS,
    useClass: CacheInterceptor,
    multi: true
  }, {
      provide: MAT_SELECT_CONFIG,
      useValue: { overlayPanelClass: 'customClass' },
    },{
      provide: ErrorHandler,
      useClass: ApplicationErrorHandler
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
