import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './common/guard/auth.guard';
import { LandingPageComponent } from './main/landing-page/landing-page.component';
import { WelcomePageComponent } from './main/welcome-page/welcome-page.component';
import { LoginComponent } from './web/login/login.component';
import { ChangePasswordComponent } from './web/change-password/change-password.component';
import { ForecastTableComponent } from './web/forecast-table/forecast-table.component';

const routes: Routes = [
  {
    path: 'welcome-page',
    component: WelcomePageComponent
  },
  {
    path: 'landing-page',
    component: LandingPageComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'list',
    component: ForecastTableComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'changePassword',
    component: ChangePasswordComponent
  },
  {
    path: '**',
    component: LoginComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
