import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Forecast_App2023';
  constructor(
    private router: Router) {
      //this.isLandingPage = (this.router.url === '/landing-page' || this.router.url === '/');
      //this.router.url = '/landing-page';
}
}
